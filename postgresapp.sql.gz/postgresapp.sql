--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "anansi";
ALTER ROLE "anansi" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;






--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "calorie-counter-api_development" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calorie-counter-api_development; Type: DATABASE; Schema: -; Owner: anansi
--

CREATE DATABASE "calorie-counter-api_development" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "calorie-counter-api_development" OWNER TO "anansi";

\connect -reuse-previous=on "dbname='calorie-counter-api_development'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: api_v1_calorie_entries; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."api_v1_calorie_entries" (
    "id" bigint NOT NULL,
    "calorie" double precision,
    "note" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "public"."api_v1_calorie_entries" OWNER TO "anansi";

--
-- Name: api_v1_calorie_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: anansi
--

CREATE SEQUENCE "public"."api_v1_calorie_entries_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."api_v1_calorie_entries_id_seq" OWNER TO "anansi";

--
-- Name: api_v1_calorie_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anansi
--

ALTER SEQUENCE "public"."api_v1_calorie_entries_id_seq" OWNED BY "public"."api_v1_calorie_entries"."id";


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."ar_internal_metadata" (
    "key" character varying NOT NULL,
    "value" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "public"."ar_internal_metadata" OWNER TO "anansi";

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."schema_migrations" (
    "version" character varying NOT NULL
);


ALTER TABLE "public"."schema_migrations" OWNER TO "anansi";

--
-- Name: api_v1_calorie_entries id; Type: DEFAULT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."api_v1_calorie_entries" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."api_v1_calorie_entries_id_seq"'::"regclass");


--
-- Data for Name: api_v1_calorie_entries; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."api_v1_calorie_entries" ("id", "calorie", "note", "created_at", "updated_at") FROM stdin;
1	580	Poke Bar - Medium Poke Bowl	2020-09-24 20:10:59.391708	2020-09-24 20:10:59.391708
2	208	Taiyaki - Ice-cream cone	2020-09-24 20:10:59.396188	2020-09-24 20:10:59.396188
3	800	Taco Truck - Chicken Burrito	2020-09-24 20:10:59.399251	2020-09-24 20:10:59.399251
4	266	Vegetable Kofta	2020-09-24 20:10:59.402273	2020-09-24 20:10:59.402273
5	304	Kung Fu Tea - Passion fruit green tea with boba	2020-09-24 20:10:59.406093	2020-09-24 20:10:59.406093
6	918	Bodega down the block - Cheese burger with all the topings...	2020-09-24 20:10:59.409188	2020-09-24 20:10:59.409188
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."ar_internal_metadata" ("key", "value", "created_at", "updated_at") FROM stdin;
environment	development	2020-09-24 20:10:54.301944	2020-09-24 20:10:54.301944
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."schema_migrations" ("version") FROM stdin;
20190318183100
\.


--
-- Name: api_v1_calorie_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anansi
--

SELECT pg_catalog.setval('"public"."api_v1_calorie_entries_id_seq"', 6, true);


--
-- Name: api_v1_calorie_entries api_v1_calorie_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."api_v1_calorie_entries"
    ADD CONSTRAINT "api_v1_calorie_entries_pkey" PRIMARY KEY ("id");


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."ar_internal_metadata"
    ADD CONSTRAINT "ar_internal_metadata_pkey" PRIMARY KEY ("key");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- PostgreSQL database dump complete
--

--
-- Database "calorie-counter-api_test" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calorie-counter-api_test; Type: DATABASE; Schema: -; Owner: anansi
--

CREATE DATABASE "calorie-counter-api_test" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "calorie-counter-api_test" OWNER TO "anansi";

\connect -reuse-previous=on "dbname='calorie-counter-api_test'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "duelyNoted_development" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: duelyNoted_development; Type: DATABASE; Schema: -; Owner: anansi
--

CREATE DATABASE "duelyNoted_development" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "duelyNoted_development" OWNER TO "anansi";

\connect "duelyNoted_development"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."ar_internal_metadata" (
    "key" character varying NOT NULL,
    "value" character varying,
    "created_at" timestamp(6) without time zone NOT NULL,
    "updated_at" timestamp(6) without time zone NOT NULL
);


ALTER TABLE "public"."ar_internal_metadata" OWNER TO "anansi";

--
-- Name: notes; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."notes" (
    "id" bigint NOT NULL,
    "title" character varying,
    "body" character varying,
    "user_id" integer,
    "created_at" timestamp(6) without time zone NOT NULL,
    "updated_at" timestamp(6) without time zone NOT NULL,
    "category" character varying
);


ALTER TABLE "public"."notes" OWNER TO "anansi";

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: anansi
--

CREATE SEQUENCE "public"."notes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."notes_id_seq" OWNER TO "anansi";

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anansi
--

ALTER SEQUENCE "public"."notes_id_seq" OWNED BY "public"."notes"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."schema_migrations" (
    "version" character varying NOT NULL
);


ALTER TABLE "public"."schema_migrations" OWNER TO "anansi";

--
-- Name: users; Type: TABLE; Schema: public; Owner: anansi
--

CREATE TABLE "public"."users" (
    "id" bigint NOT NULL,
    "username" character varying,
    "created_at" timestamp(6) without time zone NOT NULL,
    "updated_at" timestamp(6) without time zone NOT NULL,
    "password_digest" character varying
);


ALTER TABLE "public"."users" OWNER TO "anansi";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: anansi
--

CREATE SEQUENCE "public"."users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "public"."users_id_seq" OWNER TO "anansi";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anansi
--

ALTER SEQUENCE "public"."users_id_seq" OWNED BY "public"."users"."id";


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."notes" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."notes_id_seq"'::"regclass");


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."users" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."users_id_seq"'::"regclass");


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."ar_internal_metadata" ("key", "value", "created_at", "updated_at") FROM stdin;
environment	development	2020-10-19 16:19:48.570335	2020-10-19 16:19:48.570335
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."notes" ("id", "title", "body", "user_id", "created_at", "updated_at", "category") FROM stdin;
108	hi	<p>hi</p>	10	2020-10-23 15:57:38.187743	2020-10-23 15:57:38.187743	
96	Kingsport	Noisome cyclopean blasphemous daemoniac iridescence singular.	5	2020-10-22 18:39:09.625089	2020-10-22 18:39:09.625089	Literature
97	Yuggoth	Antiquarian decadent foetid loathsome dank iridescence lurk tentacles stygian.	5	2020-10-22 18:39:09.639509	2020-10-22 18:39:09.639509	Literature
98	Kadath	Foetid iridescence eldritch swarthy madness nameless.	5	2020-10-22 18:39:09.675963	2020-10-22 18:39:09.675963	Literature
100	Arkham	Tenebrous shunned unnamable foetid fainted cyclopean hideous singular.	5	2020-10-22 18:39:09.734817	2020-10-22 18:39:09.734817	Literature
102	R’lyeh	Fainted unutterable dank madness decadent stench.	5	2020-10-22 18:39:09.777176	2020-10-22 18:39:09.777176	Literature
99	Lengua	<p>Abnormal indescribable squamous cat charnel. sdfbnsdnsern</p>	5	2020-10-22 18:39:09.722396	2020-10-23 14:50:24.772976	Literature
93	Dunwich wegwg	<p>Unnamable daemoniac tentacles noisome blasphemous gambrel.awegwg</p>	5	2020-10-22 18:39:09.572355	2020-10-23 15:06:56.824634	Literature wge
106	hi	<p>My name is wiggle</p>	9	2020-10-23 15:54:21.593202	2020-10-23 15:54:21.593202	hi
112	Yikes	<p><img src="data:image/jpeg;base64,/9j/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAJ7AfMDASIAAhEBAxEB/8QAHgAAAgMBAQEBAQEAAAAAAAAABAUAAwYHCAkKAgH/xABUEAABAwIDBgMFBAYHBQYDCAMDAAQTAgUGIzMBBxIUQ1MIImMRFSRzgwkyk6MWITRCs8MlMURRUtPwChdiceMmQWGBofNUcpEZJzVkgpKx0XSiwf/EABwBAAICAwEBAAAAAAAAAAAAAAADBAUBAgYHCP/EADARAQEAAgEDAgUDBAEFAQAAAAADBBMCBRIjATMGERQiMiExQxVCUlMkNEFRYmNz/9oADAMBAAIRAxEAPwDeGNMWSTL6mZqqszyHZ55FPJ1KCoMxqz5mr01ZTUmpXcjdSPL7iDMajUjjRBuCKP8ALSsxs374i/LWzdW8MMxdT8xDnN6isNGbbpjQ5gjDGTMQA5tkOXpj1UObqR5isMaYWXQhzG9gswaGmpXzhAi1FChJqcCrMHNHHmKefLzCZSTrbpN7BEjj9MY0OY1Zix9NWGNRKTpDVfsJ/gy0kJPEXjrlVc0G37nzFJiGF9xQxpmv3xLbUFZjD09RQxoSx9RTaH9zLJ6akxDFjroiW8ggTE/fGJTLD9whfqIeb9ZO31CKw3/zrDTUrMbK+5lyKTD9o46FXs1iKBzirOvvYQxqAlkGNV84QIpCKwOQX7/y1XDlEH1FgKwmmF58tWTTFGOT8tVhDN++VTt6mUgIGMP36yKGNWYscarNJFwd3LkVcxDFj1IhrXUEm6dccfqKGN0+D6kargHsETtqs3BmV0EiItgsM8rij6arlJGMg9P0yIfMlIPqKyaEvk/DSwsmol1PmKTw+chCofRy1DGmENBesYF4TYXLIXT7irmm2+TL/mqGNXCpDNs1BoHjQxqIs+hQJsruqB7fsVZuCUdFGoJO2GIYxAupKJB/LVcxDZldH5asm6n/AKqsxpijo6axVps9Vgtnc/hqsxsrjoVhy9NBmCQwuqtNTcR5DizBiKpsklkrGIQ1AxmUmHNwR5i2L8awBqw9OMasCb2iIPplQ4f8eooHaT7hFnyBYY2UPS/DzUR/WXyDH+Ghw+orPPzXAlBYE2VpjVcwwqBDnaihtLj7SBsQOwcsg9T5asD1CDjVZs4uWSL6akNYe0tNY8aTTbNPMRBjEN9yMaHCas3aL08tGGD8L98SwYh+AO2PjLmjzI1ZtN3KyfTVctcWpFF/DUhJp15Uo0F61kxOmPLVgePLr/MVYQwljGrAmrCUY/xEwxZAMMeYL8NMAmolGSMeV6aXg1ctEBNXLprTYDAJ6wlJxxkUCGszqPTJ3EOYOb6isAGGTjIsBZMQ0gx5vcIoA1cRBqswZhfK9RWBNlEo/lpjO0R762tcqj7o/Ls/8lFPYPuFUS2djqHOe37kRR9yRL5u3QiDGJmZaDMH9eXKpUmysxs0ny0vMYfs4+omBg0Gkj6qDMbK4KCJwLzm1POgzGzdSQiYPMkXzdRLzBhzPw0mkwHMaEsaHMbNzCSjRBRTfMQ/4i1CsxoGpPPmIfYGsIh15marDBmzFIc0Y5EBNvAEWpIq8uL01ISGKST/AP3UzIdNbawrNk7ZBqvLCXMVhgfv/wANSGEXH01qFeZqV5arDxmkJIrDcEvcVZuMwSR1oCs+l6ar9hPb56FZ/X+5Kq5hmL99ASGYRK6CRKv5n5asNH9yRV9UmYhtrQwc2TUVZvzVYA1EWWq8yLudxBWpJoRD7kamj5yE+moY02moYsJRjGhgPNRtyx16WZmKw2S60+pGptD/AIKPpqGyZJKOogAzfrLmDy+4p5DeSNWGjNl5arCHK6v/AM6GdSvMl+Uq/P7ZIxIg3ABoQnU/iquEZu0lm61hjDMLTVZgj5Xg4BdxV+fU0yKGkMUnGSQmXGguqwJhm+/QWNTqk6arD9OPpxqGzhZlZflp2xqnnDGTpqwJhy+RVlMMIsuXUj9JWQjD1JSLGzvCeSUmYIQ1X5Ih+SUmop7a+2qzZ0dHHETuEWAhjZvk1C9tWB9PTFqKvaHKy6Bair1+n8xAETQ5Y8xVhNm8agcnZxj1FAmzfv5nbSy1gdmb2olJpi+SRQ0gS5Y8xVhNXLppgWGk+/XFlIiGYOpqquH2+qrDCoy0sxIpvJqxKaxdNVhyXXB1OorDB9SNBazL1Op6arMEZi+Sgg/pqByfVIVEBDXKOT8tBgcISf4yjRATEi4O71FAGHLGSVSbNjHmrTYFhuMwuPKVgQkMXyDITUkGPN01Mw20mXGoA1ASDJxlk+YsNtSbc4XHwCKRWBCOXzjIplm+4rA6slGmhsgQzdNGByfv9VBhN/jokGrA5qCxAc7MzBEF+arDGHEOOtQMko9Qo/8AjVmsLzy5SAsNthDmKzR00OHSzI1YEMAlnWH9EqIKvbTlfqUV9BdpaNlUf9aiNZex080gREk/MS8wc1MDHyiRk9TMQcxDOlJnRK1gzSIMwSReT8NNDSBk7fTQZtkIpODqRpwnMvexxZiXmzi+fpJoYM0lciDNmqOKTLzcBszTQZniYH0pEOYMwswaDgcJDC7SrNGHMVhv7iEUhoMUfnSydYcwNPj6SsMauL1FDcZpOOtVw+3qSp0hrV6OWpD7epKrNbMVZgypPkGtXmBFJQqwyBKiA8ewWnIqzBIHT00xqrMHKQ8NfblIrIf1kk6qhg9vpICuGYpMvMUCGs2ZH+IiIZhfxFDGm+5QszoA4cnMo01WbgMXj0idT1UQbJF99VnzicfprADmMhzZSIN1CZarNGYuYRbbArCHN7Y1J65Y+mrDRhy+PL9RVw5WWQQ5U5pqDm2zCJHqKBNDlk1P8aIMGH7lCr2Z22SPMSasBzSbS8BCZihjRdNWGDMKNV5kWZRKkmJNWYfHlDIVVmNCUkg9JWQzC4I9JSGYvGRAV+SJQIa+p+WiPbR21DB/V6Yk7W01h/7UTjGobYOLtk9NWHDWYqrMHuaiSx40hmj1SkVZg5XpqyGv79Fann+/+ImM6kMbTVeZ06yqzaAmXxjX+mDMbyIYDdXjoRENEsnUUhIEuoobI+4ttZetJq5fJmqBMMJeOtQOSPUUNxy6a1N1qzGh00QGQKnt9hSDjVgP+9a6hrSGv29LN1CKQklUCDLJQoCMIh8BFjUUkMweBWQ5RJB5ir1tNWZhhLTZwN1rJodPKUCKuUmXlqGtpIu3EjAmlWtBqDhDXy3nrli6asCb4UY44xqGyJI8pWGCTaIdcfUROhXkWaSkJDCVeyPaUeWWRWBN6aEhYEIw5asmhy6xxqC4PqKzLCXUy0TaalgQ5XHxqBjCoAw4vTUAaYv00DUsNnSZasDHljozFIdPMVgQjD9+tZ2Fa39Dqio2U8H9SilHBwbP61EbPUa3VjBzeDp6aDMz9jUnpJgYMO2ORVnCSP8A6ienays2cPUQ7wEJe4ORNDRoN4HK4KM1a7WxWYNAfufUQ5g6mXEmBgj00GYIzfvrZrrLzRhETMQ5wzC4CViTAwR5g6xoN4GYvkjQ2LzB1BxiLmair0ReehGGDlR8eXIqzBh8lemJALzBrCJTYEeoTLIjIZgycargH1EAPtDRKQnTU8kXno1VAhlUhmKSiv6aAHMGGStQO0eZ5+miNoaDCjVcMIv5iAHCaZrpiUhhF0lYYPbGoYMwsta1RwZQwxkGQam3jMUfUl0yEVkJA5ZBiIrISSjk6Sxqba1YdsMnGOXp6iHhhKTuIxD/ANqkItxrDmDNJliH6irMFEZewsY1XDRtLGStA1h9YuXqFVhg5WZlSqGzikGMcXzFDeppiy1Iaq8s0fnzPUVYdhAu/IiDBm/c/DUCCGQnBKo4BwzFj/iKwwaAxkoJITqZekRQ0ZhDr441DAJmZn4hEAOaT7mp9NSGH7kuarAhIfuKuaE3kWnoFmwJA+fqKswf9SIiYYXXzfylDftRB1kzFL9GutXDWEWn6eWRVh4wl1FZsNNqairhJLx5fy0MakMHUrHRlqsIa/bIiNoIZEOYMH3JUD20NJ7POqzGoD5JERCTUrzVXD+/QgvZ3qwhylAhzfTVkI5VWaSIlGp6iDNSQT+SRWBD+vpyfMUhhF1ZFZmReSWRR2daG4zFk4PTU8/tj9hZFYEJP3+kp7PYUZJEDWrAbuRSKBNk6as2ho2yEroVhvjBdpLY1q1ZD9KJQISBKONWBNWYvnHloZ1rAydT/wB1SHKzCCUCEmYSvK7aImmMOPMS2ysPBKP8yRWG0hj9RVhD1CKzREP8xHprCQw9SUiMhJEPyfmaqHCFQOrHmICwIYfIiPIbzyKsPb9ishhkk7aAhg15dYxiU1jKBDMXqqyaE0fAmBISBzCKwOf99SaEUeoRWbAzCH3BLTW01Lh/c2eRRfz51FuzrdcMH2CIQfV6arMEhtvykwKzh2k7hUPDCL1EJxfpSe1UG1a0fBqSId4HqUULMgVmzpMvSS+HK9RNDCIH75MxDmDlJuwFZg+wI69RDmCSX000MD2SDHplS94GHTlTkXWXw5qhmeUOvMJ6aYPA5UndQcM2YOsSTU4H7P8AgUDwRJgaPUQ5pFqAeWHTlUMGbpxqyGGOseaoYNYS+ckS1qA4Qwl4OBQ3AGSNEBD8L5K8ztqBZj/f1FsC8wRxySKswf8AgyyowwYfuUDVZgxCyySS/lIJkD26pI1NgSAdanTVhtLydVVm/UUnkQcr9kOZwKv1B9VQxqwuoxxRlVkOXxoAeH9fqKs4O4iIcz7irNnFjrGgBzG9PLVfk6dAxIw5vUQ/VQRVIYSyKs0gTR8eYrNHycBFWHYQJZECSswdQlamsIZOp1FZotfPpqs2kQY0HoaMPky1XmBFJq9saIDmqQE6iEcPMMOpLJ1FDcBiyE01DbCdxQwcmTqICuaYvANSEcqICGjZlj1FDM5u4Ja7QgYzbCZar8go4/w1YEMpePMUMEYdSKQqNoDmBWEv3FXDWcunllRhpAtYxjlIVSauKMhByFWxYOGuaPpqwIcrMjKjDZwvOOIgu2RQIZhZcUnTQdIPDmj1cpQ0hv8ApowNnOYXHWMghiVgbbD9wZC+oRbbZjWD2s65SEQ4eOEY9IiaGtpDadYo/TQ4bbX+/wBLqJJKsIfZ6pFAhmL2lYJnQGRQOUtKNtav2zFjzVYEKhpAl85BdzTUCag2ZxxLE2wgwc3q5Smjp9VVhDDqSllVhg0GFp/mICZhhE9JQIenWoGT2eRQIaDFIQkqzrCzbIbpxDVgf1iJmRqs3GbycashmNwLAWB2TNZCVjylZDN9JV7dL7hZCqyGsMhJIkBFPIoEM3UL9RWBklyxyxLMwsCH2Fy1PPKrA7Cfc1BqB/vGNN2hZP8A+Cis9tHbUSvsDthYw5mYh4YPvyJppdNBw/q9NbphebJ05UO8CQ0ZNVMHgNMcaDMGEvkoKnSayKzBmL2kObudRMHgfUQZgw5g8yVGtsXmyPuIM0ZvpJoYI5fuJeYIzbCZn004sHAOKSijLVZgz/ciRkNZdg+mNDmDlSdrMGRABhDQEXnIoYM0aMg/XJRQTNzCRqGDRFISTNUdrrBmDp8FCrMGs37iYBF7BZZIyeoqzBrNlk1BLNJtgcA/+mq4SGLwZokYAMxfJ+YhzcYSyUDFlZaXqAc2qPj01XAMuYMiLMGEXkVBg5SwAYGeV6arMEcpByZiI/qy6MpVmDm+cg5EwA4RyxqyGiXUy+2rDBiUhh+/mrXaAZg5uZRKNWasntVhwVh01WEJJSJnuAGYOVwUKcnpog3GI3zVX55UayKhzFoNljriiVZg+ploiHKJGq+TnKPg00UmzIH/AFag5FZDMUish9uzyVxqFD21qcrMH9fqKGCQIhqwIYcwn01DBQjq8sIvUVm39lGOOXuKwLMZhSEUDwezgzCD6i0pXW2lL15oYNBhEJRmEU5OiXtE+Ykd/wB4bGziIMeb6Yx6S53jHfM+ELgY0RS6Y45CqoyOrY/BZS6TTn+brgYwlGQhNIiX3K5MbPzBznYjbizCE5hed3n6T4qdDoO7fClJljkilTy27sbVhW1DPdXzm7uJIxtBkIURSfzFW16/Ph7ayl0DvdUNvnw4FqN3z3w5csZBjQ9y35YZ5WQD4rkfpjXM8SYb5z466xsW7UeWAeWIQ1zd5ch3K6EHagRN+oMhNX1FGn1+nP20inRJzd4uXiWYyyAtT4jfqRqWfxgWr9xjGTuE6S4XZ3hDMCOqARtxScxGTNEmgYLwVvOMT1uXqUZRUunV6czZdJhregLZ4hLdePvui5v04lqLbcgX5qMg3YyD7a8thw2SzxnakKVuUmn2lsME4qd20oyVkjILppcuv0mKdEnzd8CEkXHxxKBCTToJmLP4VxtRfmsZNQWXH6i1ATEMIZB5sXb6St8br8Oaor0S/D2wZg+0RFXDl8CaGaVmEMiHMEkscavpVnRS1lSfuBwhrMX7kSshGYsdcashJF51WHJLmLOvgVrQ0YY1If8AgVgQ5v3B9tWFD21u3Dh2ED8tSCv28cnURARQiJxqBDL1FpsCBDWbaSsY8wWYpmGLx6Sshy+BWQ+z0lj/AOgVwTG8n8RWQ5uZpqBkDpxR6kisB/8AJllQFgQzFjJlKQjl+5H3FIR9OSRWB4A6lCP5Ary5I0RDDIOivVUNtH21ZDMWRMCRV+moiIqFEB3Tk/hf6/1KszPKJ20YYMzrMGSTqKs2R9xZkkFZowxyUZiDOHTzPw00Nx9wnc00GYNZtTTRJvqKzM4SxoM4azFTQwZy8EmX6aDN+sv3yrdkvMGjaInAOLpyIMwYo+AksSYHyRcCXw5vHRWWSNDXUHgrij6irMGsIo9RGBDN55CSKQ0dSVDUvMEns01OTzdOX1Bow2t/mKuKv01IAeGDUQ/V4+0jDBh2k9JVzTNUAPmGFHwEGoEObmRoiGgItQqrMEYRE4x5ii/m21F/8JTk6A5moRG8mP8Av2qowR6a1GovMHNkr/LVcNZvPmZXpowwSBy6FWYMO2Ohbai6A4crTKQfqKuH+qNGGCSKMY1IYfItmxebVzBqo2smMMxYyfMQ8IzecY40AveBrDmdMSrhmKRMIO4McarhoNl0an+BZ9NnNHBmDm5aH9lfcTCEm2TpDVewM2ppptNiQDCGEXnIq4azFJmfTRgWcwlDBhETUkS9ZOvsDlCPqKwLNWADp+RbCw7t6zNSPn2U36Y1BrnTnw8iTj4NKe2x4Q1mFpyfTWbxs8hFAR1EPqUD/wAxdMxUGhm1yKCiH0xj1SrmdysJzPo4xdwkekL5i4nqXW6c/HN2OD0TX7jmdyCe5F4AUcs37fVKNZfFV+tuDikG1GJzcI9TVWs3tY8aYVksdq+JuBdQg+kl+73dXyb9u7fDGW4PyDG3GTpKkpbs9xbemMM3Y4JfW1r7/vkpbxdP2cEekP8A6i0BrbRZ3IwRic3AuYQkmU1GtRjZ4DCrAhCVyuBDjGQi53ja/EsODSXGv9sdag/4Y1W7aUTvSU+E3P8Ae1eCYquo2ICfD6rj1UrsNhrNfiMaM3qEj/hozd6Ebxq4uTvMIKQmYNMLDHYbW4fV0auZmKylXXPWg0ls/NXg+ztA2u4VtCZZbhGSPSj9T8MigbaO2unAKBlkE4ISRNLPbR2Hd83kJGS8vMsfpyf+4rLlG8MR8CSQo8wfaS51obKU9azCphmjHlcwUeYMnVRF4w17t2Ed0UELbxZZI9Vr6iT341DMY3YyRRE+IH6a2mFTDv1hHXGIZBSDJ/lopQT+9Xhs1ZnQ5CDk6Zx9XtrpGCcYVhEMZM3Mj7aw9tsPuEreiiiW3l0//wAqTtpwE1dmKQ5Mwf8AaB9pRaV7DJydU92juTUZ2sQyemgwvPeTojGsfLPBE/FSvBGJKwum45BOW5dMhP4a2l4wqPFTWcGW4Fpk/lqzwer3mrs3pE6M+8ttbMvnGUURIlWUOVljkTy2mIYRKHQxxiy8zVEl9ysJLa68+aMumQa7rB6twvNxvUek0hz+cwZgzFjrzMyRWQklUCIgdqhu37FbelFOmtpqBDm8fUUCEZvuZXqKwIYfUl7iNYQIZyqyHZtL0pBKGDWYv3BfMUCGB3ISJAQ0YMz8tQOkQkZM3uKGNmjyxqwOdJ1Ro1hZ7Bh8lY//ANishIYQ/OKNVwENH5/w0QEMIo0wIHbQGPqqaxeBQMn+CJEBzvOSLKR5A/kYSbKNnkUVvk9VRba6B6FMGEZCD/MS8/8A3JwcNZix5sfqIMwemSLKWqYVmFCXMzEGYP0k0exhkQZs4sZKB/MQCswCbBR0ZaDMHNGONNDBrCLUQZwzC+5mCTGu0rMGbydQSDMGg4icdCaGDNljyidRDmtswssi21ti+HqUZSrMCsxdTMEjIa4ZFXD7MwY41qA5g/SVZvpIyH6vcVcPU/8AVSADMHp6vy1XDlE46MtMIYczK9NDmBX9NJ2AHDlKswfhfUTAISGVcMxZEkB4ZtslY9JV5Zi5aIMGuFVm2k7aYAZmZAl8moXuKvaGsJY0ZDpydL1FDccvHpdtLa6i+GYvkrVcMOZ2ifiowwMqRTZGEQ64ykQNRfDWH5hfylWXJLGmEMEfq9xDwjMLTiInbBqBxVoeEYS+mmBg1qQzCkWpesrMH81VmZZQ/wCYmBgzbPOpCQ0nkKpDYvCH/gi+WrGdtIYvBGQhPTRgLbW8KMdEpJemNdo3P7gThat3z4ZSOC5jcHaVXnZuuawxcGlKMvu93VktpRvnwxkJ/Zxp5crCczqPqC6fSEumGs4AlIMZJHAtQg9IXyxrB4kec4UjFjQXlxftByEi+ouAzc6nOne7rBwpzczxIz5y6OANSSxZbg5M1cX38byPcAiWOwRcx1CSZovqLrG/7eEDAVh91W0f9IFHJGPSF6hPUXnfB+72vEl0cPn0pW4sxwQnV9NUG1Z0lQn3e7txhf8AvV1mEKQhBkJ1e4QnprebvWfv6/DvBP2MRI2/qj7irvFt5y6e6uOKVvJdKx/2Vv204C8IHC4qx0DFL+zjo6Qx6ai1rsSNXYx+Kg/phjIYyVk5O1klIPpFJ0xrme+a8V366cqAheXFlfNIuyY2DRhrC8ZCC94Ou33FyM2G63l0GCij4hGNUUkrttnJbcGx6Qy5aIv1t/oFuxB+0OiDGNai/YbIEVvYx+o4+WNOMN2ABsRtzkGIbezN+ZIQiPqeewauxj8VB/7W2fD4BjjszeRx8wg1m2Tyt5ebgMdZeXE3INaiwyXK84gvlfVGQhCdoayeCbaR46eEzc1uQqlTr40akjC5GrN7voJ1W8cfdWo3YhJbXfAeuWL4Ynqj6ZErvFtrDy8eaSQeYT5aeYPthDCb+Qoxycs47oiSZZFilO/gXOTYZdndEAccrMvT/mJoa3DKwbuqM1vHHIPqjVlhs5MSYXH5BFcCyyfMGnG7EIA3lxYzkJy7rMbkJ0idtRtnelamfwqzGF1yJMpuUkjf0iLqm7ExAunDF9XKTpkWLxJg8ltug6yDjIXLITtEW4w2zHcmo3w6IngoxuMzV7f5azKjFTjG2Fa7aUZKMzLlIk7MIwuuCv8AZy/lLrGCWYN4VgjIQfMF05O51BrH3jBPu1/BmizCRjVljVpOmyatycadJsPfrDA546NNL4coi3DNkSMjUlGX0ySLN3K2jtrrMHliXfdJ6lwpNwHUsGk+ewvCEZtkdH1CEU2ao/bpogJh7Ck1VWYP+P6fpK/VM5qwmmKShSGjqZisCzHLIREQwiHIg4HCQOn+WiAhhFGrAhomVgQ0G1KIkBWEPxWp8tWQkDJxqyGjYUash1OqgmquGb7mmrNgZhR1j0kRDlDy1ZsZkCWRDVXERRMPw1EB3iGYumhzZMhJJE0MDNkQZg538tCdqJzZ5SeTMQ5jQycY4hiTQwawyD4EvOEezLJXJloGovNIbMGPLQ5g0JgYGpH+GgzbJv3EwvX5C8wOmg4SF8mmmhg0B/cQ5gzbCEjW0mxXDBJGoYMIkQYPxSkExeCtEm2oPDXESjMGq4YNvnH9QasMGsH8xQwZpPPll01q1BmCQPnUNHlyIyGvlSD48xVmDQH7+YgAzBVZg5WYNGG25RKKK4/UVewMBuAhJSdxABmDQCOShVmCMxR16iMm1B1jVYdIkg0AGZnMUmnldMmqqzBmy9tGWmG3bQHyaqrmzSUD1EsA4YRZhJB9tVnDCIeoQaM0lDSbY9US22gvMD9zp/wlDA6aM6f1FIaP8a1BeYJIvqKs37LGPLRBg/N1FXo+T+InbGNpfDN5yRKe0hvIP8NMPIbyRrpHh73Mj3hXlu6dZbcRJCSemoubk65pOLjbKa2o8NO40fK+/LqPM/s4yLslyttZiuB0RCIUfxBB9IarC8mLwDyhyRtxj6qIvBq2dq5FqMXOFy5OquAzc6lKfe7rBwdc3P8AGDyszUltYjGWIccka5vvIvwN2+HCEoHK4dfs449Unc+WuwXjCo7C1cT1yjEORwTqlXB94QffDtxdX3cjbj7S5ytXQY0nn/FVtfX6/R5rm4P81wQfS9NPHmFQYVw5JGIbdqOSMfVItxgnBJJnFyroHzBcsfpDSPG1tov2I29qzRt9Rx8tVtKJupy+5YbrtthIQ9cV0xaTmXBO0zH0/qaicYVZ+/nTcmXy7XM/y04x5bR3+6OKxj1RjbDH2hj6i0Fhwr7hwQ4d1giI6Gk09Rq8jj+8n+mMU5n7OLLQeCcHjNfuMlGk3IUa2DzB9Zry4rro6a0GFcEw8xWQeqQbb6eoT+GtNqT9N3ud+4SPMUE8hCxZY5EwxVbPc+CHA443F5cRj7sY1sLDhUl4fzjyyFcEJ+Yk++Cz13LFDMAx/DsG8Q/mInX+RG1Ob22ww4XumXqxtpO7mSfy1n92+HCGxGOiPLKzJH8xdQeWKsO75wMdERHTwZPwxkS/djYpsW28ZBkL8ORSZV8ZU5E9+w3QZg4ojzBEGSTqiTDBNtGa6PGuYLnxjJJ1cwci2FywrW8dvKBjLHy+X9NB4Ws5zOreSgfxBW+p6g1jb/GPpmkwJbSBxQ3OQcTguW8H0hE6ZE4x5g8dhugzj1BEkk9NNLazovF0b11jEMl0bxEJ2idxdEv2Gq8SYDZ3XgERwLLcDINH5l62PxIz/TCwtyUAj5oY5PSJ1P8AMS/d6b3BdCDr6RBjIP0yaZF0Tdvhudg8tRKJXgpCN5Pl5ayeK8ODs+MmZxjLy90HGT0idRNl9hdJtphUH6H3CejLbl1I+kRbi+4VBiq1jfAoiIUcbiNZ/BLOu/WYjGugZHDXLJ/mJ5uluZOacWMh/iCjy/8AM/Dy1ZSRazcvxVZ/drohODSJGSPtpXfrD7ytc9BNIcf011jFWFa3johIxx5mX6f/AE1h7aGuz3SAhBlHpjH6andNyaQoqc7GnSetzMzQgRfclVfSjzfmLUY7sJLDdJBj/o8uY3WfCGHzkJKMsa9HwcnhSex55k41J0VmZ1hj4BqXIwzF8gyiGIfUJKiISZY5MtWGDDpyfMUljUX60fURGZ9xWB1fJLqIgLP4smYm7S9gPWL3YkZreTgU2hhj8nURAQ0BL5FhsHMEgRDGrAhIHMJmy9xWHCQwpM1QPU8hEE63+DD5Nmmov65Mf95VEDW9JnDlcAyDGg4c3upwYPwuZQl5g/q08tLWROb1EGZnlaacGCPTQZsn7nSTATmDlSDQ5gpwbZMGQemlZgxJg1lZgwly9NDmDm5dcScGDD00GYM3nJRpIRtReYMIiKHDNH1VYEM339NWQjD0/qKQyX8n++TKlVZwQ+SPLTAwfZ9wkiHMHJ1Eif3gPyZAl2Icwc3goTAwaAizJfpocwK4h9JFQHMz9ho0PDQf7+p00wMEmX1UPDp5YpFgA4aIsv8AaOooEJOppozYHNy483UUhhjjGUhEAHydEsnAMSrhHN0kwhlQYQwemRBgeGEWX1VZtDMIdGqocNBvJleooYObHGUaCw8NGnqkVZu51EZDCWQfbQ8M0lBEMagZgzFGQeWMWoh4P3/4iaGDWHbHHEq4Sfc4JVpX1+RmpZhXCpL86jjkHIvSlhCPd7hJvbgViE4KP4iPpLm+5mw/FcfAMjdqORwTukWwDJfrzAOMcpJCekNcb1vqPfTXN2XScHsnsbywmoC1HX0y5jf0h9xaiw2eEpHRxiI4LmDH2ln7CcjxqSusYh9QY5NIY9Mf8Qi0hrlXbWA3fGQpCjy1y9KuolNz/Hm0mMMRksY6CRizHhB9UfbXH94WFR3i/QUDLy4iRtyD6o+oReiLlYR2CwuOM/xD8kjgg9WPqfhrD23B+VzdYyClJ0+3qDVbSa2n6eNzN5YR2HDoxjoIJwUfb6a5/ZsKw+8LkfKcF0yEHmxrtm8Kw1mawDok5rLGP+Is3fsNj5UbWgeZlyZarKm+k3Hw4O95XQg49VxGP5a0mMLPC15SOQYssg10zDe7323mSMRCCGTTRBt2/OFbyDlcFkI4y0kyfuOJs93tfNDJpdQiaforDZuOMuU3I5IT1CD/AOmusPMB1/fookIUmWNGYq3e+7bNcIxiKQTcYxyfTW3pKiTSk3J93u70gWAzjoFlNx5ZB/UXL8SW0hsW3A9YyEblcRjGvXjywjtmF7hGMpXDVuMeWPqEXGzYJr98t6OAeaQhEUn2IU597ldywrDa2bXNJK4ITT/13FXgnBPu2/NyV6gox/mSLqGN8EkDdGYBxj5VvJ+JlqzCuFRmxHHGPl3TcazIzWzZsHkDi26NCD6kg/qJPYcHktrqQlETi13AfMfLJ1PyxrvGMMH0GxHa31A4pRkbEWbZ4PIG8vGkhPj25BjJqZg8wf8ADTKTLY+24VoM/cAjjIInMtyD6uZp/hkXYNzLNrfhXC1E07oMkcnSINJ/0bmsLO6jGMcTj7nzB/6H9NPMKm9w4yH5BCG6zG4/UGpskakw9tsFdtujd8MfxDBxG49Ug9ND74N3o3mHHD5iMscY3rePpdwa6ZfrDQe/OCUD+HvLfmY/U6iMttgA8w5ytZJRiy/lDIP/ANxN1IVKuL4DvA2b63vo5R3RuMZPVImm8K3Hw3dB3VjGIkkg4/8AXzFNmFa7OwuAB0SEsziRv8taAwaMb4Nb15RZW8o8vqaibOnZ40Wk+/yB788Y373e+AQpW78fMjJ8zUWTxthWEYz0UZgiRyD7aswrcYfeFtJLHayc63H6ZNQf4ieXON4IY5ClHHGSPt9MiZ+aNr7GHuTMeMMLkY/2xrmD+YubmDWEsZNQWWRdIMGuw3n5TgeZ6aR7wrOAN+5qgcbd0OQY11PQM3+Ojm+rY3f5JseEPUo6qshr0ydIfbRBuAJfIrIZv3y/MXauQLwhmj4MruDRAWeblqwLP2ySDLmojk4dRAVhDQUXcUM0HtzCEREMPn0lAh9rnjry0xtr7A4QkEIlfdVgbb/xqyHKy9P1EQEMJdTMWdrUHFWPy+3+pRHjHFRsp/uUWA9GmZzC4KyFLmIMwYdNPNmz98lCXmZzFkS0wjMEcpCD+ohzaseYnhg5RMxKzM/ipOMqbtBXDMWTpocwRhLGnBg/v5sfbS8wZhcHURIE5g5UciD26ROCX000Mzh+4hzSe3gyhpkgXh4BB+aqzBoi1EZyepJqKGDQEXn6SzUqky8wYdg6P4aHMH4oldGaP1EYcJDeehVmDpxok0DwD6iDh2GkHmJgYMHqKuGv25ZIkygBwwiy6FWYOUmENYTSRqs2SaQmmVJAOGESrOHKGPqIwIfhY9UarMGiLgklGgA/mf8AmobaPtog1toMIcep8xVmDld2JLSFZv1C4+AaHhrNqIgP+DUUhrL5MsSCdQeGAo+ChDw1mL81MAhIZr1JFXCQO2RDYGYI5Y5NJWW0I9rqQmXF21ZFXJH+YiLaEdyxGzYxy804/CULOrrgsemy331ukWFn7twaMcZRkLmE+WtBgNnC1cEj+IdZYydoaTvJHhiRkLy+WMYxrQBeUBdcAyZjVvH8peb1rTnR6HGWuetuLPAETegdZRDKTMk6S0AbkO5XUnkHy7DTITqkWHwrfq+auhyZjdg3HJ8wiIDjahnH6UZSE9RRtqylJsLxtI8K44xi5fqIczOazcccUuWOPVj6n+vUS/3lRcbW3GMnUkcDWouUe3LHRltRjG4zOoTU/lqNT70pgzWAlzdEJ2vylnw4brNeXFceWKQhF0R4aFg4oy5NMilhtoAtRyRCGXU+X1FC1GEeG8Ek5AhIxjcFIMYydruJhbcKkPfrhwaYhxrUB4wtW8g8wQyEJ8zURGFQj9wuK68ohSSEUmWMNrNhwSMz9wOvNiIOND42w3R7huHkkGJwOT5fUWotsfv5xWQnTy0OENFy2RniJE4IQn0xopOfeXWrP3/DdBsJOCUajog+n21y95gPnMeWuMcsUn8Nd0eXIZsOM4xySjkjWXZhoZ7xpIxRi1JPlpeRLgJVcvxtg8ZsRvD0URDEzGMf0yZirDgkhn7cnAIYxD/mZa6ZiSzjeNbgSPMLJHH8tRpYaAlbj45CRj++sSl96TOvjZ+/YVIa1uKK8twwcDIOPtkSe5YPoZ4o88QxicScf1Mz8tdMv1nmujgHBE3ftyDIk7y2j5odBB+mT+Z/LRWRW1j7BhWFrcLUSLNkH9QZJBpPcrOSJm+ooj5AkmWTpk1BroF+Zjtt5cO6NMpBuY/y0vxJYRhK3ooy2+YP6ZFmZX5mnvIf6ODrjlcMHAy8fpkyyIy2ioMK4A0nBZMsfc1BrP4PeQtW43emUZGTj6iIt2IxmulvOSjMKMjZwP1BqTJCrInuQRmxQ3dRxDujeNwP1Fl8KvCW108tRCDFEQkfqrSX65AZ7CD0iNXGXJ6ixeNnnu3FvNjJHLGTT/11FIpNBJ8VB/RXG9vff2d0SNwT5isDcqw7HDWOIghkGRV74QkuWEnFFFcsUhG/pE1Fk7Djai5Om9ZDy+9G+Z8wajbOzmj09tqMVvKLkwb1gHKR03IMnzFkzG9/2IgK/wBoa5gyJhfnnJYXGQemJwMizYXg7biiDj+HLmfiZis8HJ5zpwQMmffPmrhry+MmYVQuSKOPLKiDs4X5BkoyxEy1ZD2xkIvR5U2T2OBrLXQPmGjo4IiKwwZto9UnzER7KzEy8vMUCHNjrJlqS0Vwk9sihgjPHlogOzJ1MwSsCH9QyaSGNReEOUjAhoy+orIRhL9xEBBR9RDRTQzo4Nmr/wDVRWj+5sUQY9IvAw5eaMaHMEf3Bpof/AQaDhJLwV/iJaYTmCQxdP8ALQbwJJdPLk1Bp4YI4iR15iXmDXF1EwFZg5XVjQZg1pwYP+PT6iXvAj6eaNMLJzBzePjRHvijZhIlqrtrErgriQb8kgyi9PtxqwwR/cokjQ5snT1EArM0ysuKRDmDDt86aHDMImWq4aAx0d3uJ0gT8nNpqGZ0Bj1JEQ8CQweONVmydgyDTgXwklVZg1hk4yJhyemQlESkMJZEmn7laivYCaNTMi6aMCEmwshCIc7OEpMzVTfT9mfIrCEmpxquEhkRDXEShQIZtuZlRJDGvvDnDD1BKsOkSSL6aYQjiQ8XTjW2syVC8IfivOOP1FNofYUhOmjDBmLmKGDm+mkj8y8wcrgzVXDWHqFTAwZmpKFXDFljiQyDPsIEPHmkRm5kPvLGVwfEJKRqOMfy0PeMlg4jrjIVNNzIRhFcKB/tBRjzPTXMdfr/ABuk6JL+RtLaYALoOvMjFIRSwmI8auHZK4m/MEzBpPfrkQPMUcYhDE3kJH3Ejtt+rBhKQdZI+XIST5i4ilfI7XGm3gcSDtu6UhyEKIl5ukvzRj/0NZ82NoeXHJKQpJFn94V+hsOHxjd5Ym5CR/hrNiv1Dy/MxyRDKSQnzFXVp5F5KXjemN3ty95FZyZgxag1pC37nGAx1/2p4Qg48zLkXM929/otjVwQlckTcki1mFb8MwrPRxxRDjUj8Jsa/IMeX7nSuBkrkHIQWWROLMCgzVvRIIpI5JB+ouV23EubdIyDGQTwg5Py1rA42Hbbh5IxDyxqNNmknTGdyGZ3cK5JR5YxjH8tMLaCgGHMvKlXL7PjCZq46ZCuCE/hrYPMScnaxj7o/wAJXeN+CNSX6iDPBhulwHX0nAx/TUCGEVwJH3CanTjWXxVfiBuDgg6xZsZPppf+nnx90HPmCtZCSfTUKusykm0tph+6rfQPqsxkQ9hNQbG9wHXHIImZIsXhXeHQa1t6yE0htxk9JNN3uKwGxveMwX7QSQkekl7Jl6zy/Br96EBlR8wRQIRmaEoryiR5az9yxUM2LMskkQySermJgK/Decx0suNSJTmNfjaS/GGYtvjjzR9RZu8XIZnQ6K6BilkHl/69NEX6/fFN+MghN8vMWLxJiqFpIMeYJwQcnd7aXQa2kxJeB3JqzrjLGWQX/uJf74ouWFx11xSRxLLmxsMLXgIeQZSSD/19RL7diqgLq6MRkH+0ZY/mKFSgocTTNXgwZWYMn8T+ZGkdzv1YXTg4K4h8wO4j+plkQ4cUwunFGrlj/iDWDuWKpmo6xk0hkbEzOnqfy0ylewrU0m8LEsL95wElijJ9NGY2KC5MG5CaZfhiE+YPLXJ8YY8GV1bzyftQ4yZnbWgeYwrZ7vm/HmuBOBkkGmTyZ80KsuwYG5e+d3zgGaNwIcn4ZP8AqLjdtvFdndN5Ky/AXAg/pkXSLDcqAurgDplIQeYNcfxKaErgknbJ+GRRq1Rdbpm8K5D/AN2l4IMmkOSRI/f1FywlY7qOUgyt4yekQZP+oq7k8ruW764Ar0ytxrD7pbwR5uqcMePMtdw/LIpUq/gja3YGZveTAZ6M1ujIaNQdCze7G5DuTUY669Ia2EPU6ZV6P0mvfBwvUpa8gOEMPkjVZgkN5IxSIgIazFRkNYS6Ys3qK7Vmov8AOZWCNMKPgiRkI+51FYFnRF3UemtqXmCTU40RD836iIho6Y1YENYfvxJgV+z/AIFETCP/AAbVEB6PhmESuMmahzB9QicQjC6jQZgxdRR0jYRvAzFzCIMwc7yUJ4ZmSUZBjF9Tqpe8ZDy5MyJMMJ3ge4RDw0R8cZU4MGEeoUXqE0kvMEhhdVZmXzJ3gYXQycEarMzmKTLTQzMncEUiDMEhi5mn6a3b+heEM2wnHR8uNBmDNHx0R5icGCSXgzPpoczMkXnrkGLUy1mdWScwfYXyEkGqyhGHZGNODM5hSccSDMGHpyeotyyswaIlXDMHgTAzPKJ/MQ5s3L9NbSBfycwiekoHgi469NGQ5XBQq4YS/fHIioBhDCLp5qhgkCKRGGDmxkoGJTk83LzVqAe0MPb+YqzBrl08r1EwMGYuXF8tSEemT8RAKzhrNl9NVmkNHRXHlJgYM+nQQsSrMGcUmaQfTkWlQXw+0uWNVhDm5kaMhrMXg0u4NVmCMMhMomWlUEmTx5fqLa1kIPM1CDItBuNvA+VuB6x5cYxjXM959yJfcRt2kmW6cDGOTq9yRdYwGzoDYXFA5P2iPT9NcD1avfkO66bLsmV7yMSEDYbgTKEQpIlm7jfv/u5IcZ8wTcY41ZvUMQ1hefMk86xdnuVd+3c3gEmWJuMg41zdPcdTKfjaDeRfiB5Pz5YmcY0nw3fob83JWTLjkk9RWbzpDWGznHF+zxEj7iT2039KtxkypRjHmaqrNlNi7lTwO+W3FRAsHgB6nL6i0gsYDaOrGfUlH/mRrkby8V+6yOqKxDibxk+ZJqJ4fElDzDdrOPTFqKVs9ROYjZioltf3AFdEUrghPzEZbd4XOOnBCemTLWHvFyHciuHQK5CCJmDQeG3hDFcRkyyjzCEUKlNdEic3eLDioYmrfgITNbk1PUIt5fr9X+i4yZRctcDwTfh8g3zJYstdM/SSg2HIz0RdNX+NXxl1kDx5jYgWrclGXK3StnjCa6OKyR/FWsgyLN42vE1mk0iCJl5iz9nvHtzCEJ+zk/DVbWnkGtpLDirk3UcmWVwNWbvd5xGeLbxXJquCEJ+IubhxJRtdEr0okvtmJBhvLzVkKRRfqfIb6Y3fwd0DvCrDi1vxkHI6bx/mLUYVxsO5MHBJOplrznfsSEDjdn5ySCb6n05FvN29+mszeiSUhVKwsnvoxTGdgv8AfvinA+MeUMZFg7ljaawvOMeYJxpoO/XjNJRWSUkfTIsuzvxJbhRqjLGmVr5Bq8au542rCVv1RicEFlqw+MIbyR1J8Q6b6faINc3v1yynAxk0iSRoe5YqIZrbzkjyiRuJFU0p5C6S8bqH+8Lk7m3IQYiS5f5i52bFU1wcUSDEMrgmn8z/AKiDvGKhhE3IQnUjJ/r6a5+bElYcZPAUVjIPLJ9NMrXxoWtsL9fpsLkJJmMHBBjThnir3lghwPjzCxk+aub3K/fAXCiSQZSSJhhu5ENYSUao+pmeml41VbkzdEsN+gvxKKyRy6i5/fjVma3AckhBSDTCxX6szqTtDjSeaa6XDMzC5hEylO9FpM4ueJOT3cuCVkzBNx/hrN7mbnRbbnfGNZMsuYNWXJ4P/d88HwSSt4xkWTwfcocUW84x/Dum8ZMxSZU8aNrd43PmmvzgAx5ZZF0zYzHEOvjXG9zNy/7ZQDrilzBkXcAhoi6q9E+F6d8HE9an2XDhD8Vl0IgwR5fkRPJj/v2r/NEvalXUKUOEGbmZigQjl6iIh1MseV1FYYNCADMGJWQzFzBqwwSGjHQiAh9TSTAD5Mn9+xRGKIL8j0wY2bx5okOZpQb9zL1MxODBzR9tBmDmk45EtII7kGH1P4QkOYOVmfhpxcgw7Yx9VBvA5vnozEz01gnMGbySZaDMHN4E4Mzo7iDMGF1HwSpgpMnMzHKSMiHMCgOoOMiaGZ0B+/QVDmDRF0vqILL4Rm+Yg9oYZB1k1cxNDBIEWXp9xDmDDmDH9RaTMJzBoCIY65UObjljy404MH9/U+mhzBGYvzVuWXmDWb7/AEkGYMwiR5aaGD7Msen1FXyeZJ2k2QKwhoUMHURkM5ZCZarNklTwX8mPLjy1DBGYscaYGDQEWXqKswc2TSQAZgy91QIaNQiMhIIpPVGqzBIGNRwXmDmky1NYWZWWNMDBr1CUIfk68uiMSWAf9eXRmpXfmdZreSigeYtJDBqKswR7RE4/1LSv4GS8bidywqT9N25yDibikKP0iLom725Ue5nA45SCcSE/DWf3nMyWy82+uSNuXUXJ7bvs/Q/FFwHXRFLGTU1dNcBmz7L89jusGvfB0zfkGHC7jgJIQq43u93nWq23S4WYlEjgo44+11Fi9/3i0rNhwjUEsjWQkfppf4XbC6xg7b4gdgFzDog/w1R0kvMane7hjDEg7lYmbEZJXDVwOQY+2mHuCgzpuQlYyuPmaS5HvI3hXGw4ycMbdbSEJ3+kpYcb3kLQZycyUkkZCEUfUupV/R2wNhO8akoGeUfMSRraWHd6c1g5SSUZRyDH2l5zNvyutuyGoB8x3JFpLDv+xBbSyOqxkIIfTzVJ8Zu11R5uHffuELm5izYd2GJ8NviD4JW5csZFj2fi6xAG8kJlkGL9wi6JhvxdDNbyEfAGJuIfbSqTnzNlU8wTgO4hdEoPRmFIPprcBwo+A1cDrIT0yLP4D3/McSDG7rrGPtjXVLa8ouTXLIMUuYpspzFKuR37CtxM1eDHRl6mYub225XJm6jOMvb016kMzAYROkT1Er/Qm2804rPQLN9NFOm/yFTyXl+asN+IMlBPlpOG5V++XH4i9UXLdjambrmyAGOVZM25mxmuhHwBiGPqKpp0pOnkzcPNf53QydpuRbjdXfvYUY5CDi6a0lz3b4StoiSPhCcF6aIs+FbdbXfHQcZBlHlkSsbCpOg+omX355C/Jx9VI2dyIG/cEkYyp5eLDQZ1ISvS00nv1gzpKK8wQ1JpJja5/ip5C6cR19RZ95eMrlSEyyrQX6znM/ISOUaw+MDEtrrz0EGNUlZU2DaaXK8ZvBXFmx/SWHuTwn6ZOCV16rdPHlz5x034PTGs/fjEDigZK/8A4eNZnNFGXK5Qi+/lljRmCbkQISDkyykzFn3pqDFJx9JV4VuUN+GAmYOMhCJU5q+sm8sLygNwcfUS9m8Ia8vKOMUhW6HA9hEQg+2T8QiDZmhK8PXqcuNMnNGqcPHo/czgfdbrB4VN8Mz4IsokeZ9Rai5PBhj4MuVuRc/wHciGKQZOk4IP+IpM/aQdf37HpDdKEf6bt5OqvQjOTqS9xec9zJucxbbyemvSgQki9Nei/CevW4n4g9xXDRL6amWEpO2rAhH7YyD+orA/1eegS7Bz+sPlmF2sz8VSKAWmMQ1YYJNohxjESXUVkM0dGYNDOtWYOarIen/6KwIZvP1FA55cyiLpoCvaz/uUREJP8GxRAeoIcr5pEOYOoMicQ0S8dFCXmDQEpP5iWYT8nCXyIc4cog04Mzoi1I0GZmSXUy0AjMGtDmZ1/fHqJwYNcunINVlZ9sibMEZrbNmEQZmeV5E8NbiZlBNND+7ZhacsS3BOYJIszqpeYI5OPj0k8MzmLx1xKvkx5kiWGfMzypMxBwj9sg5U8MzhMSNDmD1CEUrYCsIf65BqswaDCTgwaIkOYOVlrUsrhyvUVZmeaTLTTk8pDmZjNlk1FtsMLzBGHYSMmWJVmts2X9RMDM6w5ZBqBCQ3dGtS6F5gTB09LLQ5memMZPy005LKJ6XcVYQ0G2fciQC8wawxjzVAhm+/qJgZnChzBr9si12AHszhE4/yxquEcXklTDzykjo/MUhmajGPU1Fin3hl8bYK/SqwuAV0R5ZI/SIvI+/jca+wrhxvcqJCk5gg9PS+YvcAWc33x5Ylg/EVhsdy3X3AY6NUnbXP9Wwp857F/wBIyabNb5l3Kz/pU/byZhMwa9mbk8B0WHAdvoHRHE3GuBs91ZwlcH4Im4pCRr1hufthDYNt8chBxjXFcKT5/g7qUqT5+QvuWCbVZ5DnHK4L01MN7h75vCjHbWJBsxaZNKJdMwru3aPL+3fXWv4cWmPukk013zCsgbD8CCVuLTHpiEmSxu9P2z4TeR3n2e762iIQg5HHUjcLB4q8Or7d6InPAcjbl1Cagl9GGdtOZqMhCW0Qy5ZJHg0jxJbSGszidoJ83Llx1jGUX+sxSKdNRfqXzL/3Y1mESsBJSF1PSQ9zwqczVuAmU3FqEXpDfBuxY2F04PZmgxMyjkIPq5nb/wAtcjMGi5icE4xDiJFlySl9RVNMbya06Vf+7LhuVeD3TMlFZSDKP8xelNwO8IlysrfnqxSFHqE1Vws0BSjAfNJJ2+n/AKjXWNydhHYbMMfUETMImynrSNne7x7yYha8ZCJe8xXQHz0Dy/TSt5cqDMODLkWbeGh+/WRTtnqzSYi/YkreOySVkjWD3qb4CWGzEYsXYxuCjISTtKy/Xj3a1IQZOouN42Ce/YjJlyDLljIPtqDkN5Uc3v28K64kvLh3zTkY5Ix+qmln32Xyzl4xuilJ/CWktu5kfK8B6xCb9SRPLDurtRnQ6GgCOSC7Y5FC9J0LZMW+bFz3MoIUgy+mmgd/2IAMIzsZXHcXUP0JPbWsY8MPXI//APHSu4mw4EpAPmJWTguXGQcakahsc/Dv99gs8ZEGbeFar95H1A4y6ZFuL/uZw/ePO0yidMixeMPD2QLUkboeao1J97OzsSz21q9dSNDiIPqJfiTB5DOpKMyKSNZcOCcR4VfkroJLFmDjJqrpjMxLkwbkrojcFHIQajUkxsc3uRiMykHGXKHmJfhvg94ODjJLE3iXQMVYVouQnBMsWWud+7a7CIgx0FjkzFH1F0p3ml+vHJ2sYKJZCkjGrDG9jBwMlcWWMa5W83nc3i4lBK4oswknSzFsA4kBeGrcfHFLmEIsUxqTVtKNBfrlXyrigZNJusXgMwzX64DGTM5ghPzE0uTz4BxXx5ZUn3YmhxlcBkjky/xJFpL+9s9Ubjbb/wBo2ddf/wAOvRm0NYdg8zLj7i4n4abOR46JX2oxrvAQkDH1V6X8Nz7Md591+nkBmNM14BjkUhyvJ9RGecOpmqGZzfcy4l1KgDhDXFmEiGrDB9hR+Qo0QYMOZwKvaHNkGmBXDWaPMLGrNgRh2R5XpogIZhZlCgQjD98Y/qDRsMfyMB9tGz27RKIggfPtzFEwPURgzCy0PDD5I04MzIcQyUIMzOsOoQcijmF5mdGzU1EG9Z5vzU4CHJ89CHhIUunIgsjMCGPyZZUGdnN/yEnhrbXKhzM6AyJgZ8zOYvkQ5gw+RODBhETz6qrKzm7qNYJzM4Rd1DmD8L6iYGZkzMtBmCT2aaAVw+ohzAGH7+mnBmdZ9MZVBMsrzxoDPmZk9JVwjMJODBGEUaHhGbp+xMBWZnMpyUxcuJMDWzOy8oanu4n/AIILJzBoNIoFnmxkyvUTSKhVw0AF581bSBWYNH3KM0emoYPToRkGbmZQ1DAoML7iNgL+Tyukh+TJ/fsTSGs2wkY4vmKv0+CQgljYYXwwR+SQnUUhhN50w5OuXjUCzzfOsAv92kkj6Ze2k+8O285hJ5HRlxyLYM2cJeDp6ih7aMwiDroyyjjjIo2bPhzx+c/ROwa+k8jhR4zuWA62dhxAPqFcZY/TXVPDTbf+y7OgmpGMSYGwryd5uDEma3j7aH3V8dndQDJGMRI4yLzSc9VNdHrOR2Xx9kzDf9v+tXh1tdvrdAJcr4/G49120eqUmVH/ABF5P8Y3iK32Ybw5hfmrz+jbjEchG9tYZpRDH3F68vHh1Y42x4O8viS3QrcY2ZyZvIEGQZBx/UGuR/aZeGnE2MMD2vE9ttRX14wvIN4wGPNKzJmSDk7ZMyNdJ0mUOdO+jjurUy5w8bifh13Vut4TC4fp3v3fWlwIY3rdgS+RFK3jIQhBjH8vTH3F6Q3M4pwPft7+G911gx5igWICsyXId2G4JE6IMchGUZNQnUkXz4xHuCwBvHa2PFt8vl2E4YxjjaEj5UmpmdvMGvWf2fuCQb/vGvY8T4ftQhWPAYyPbg/GMkRXBBxjHJ1NQhMvtrrKzhr19nBwss3L50758+b0hvC8N+8Zn7wdDfW3ElvE4Jy9BBxPhDHpjk6hI1wt5u9v+Kry3Ygwq+LcMyMYHGaKMeZIvo5ja2kvDUeQVi3a6bgjiOIi4fft27FndHBwX+Jw/bxEGwHIWPqfLXA5OFP6jxvYukZFOeP5HlfdjuxAbesSwYgaYtYvGFrI9IN+zypB9MhPxF0iwhHzXBRpi010C8W2i2iHh/D9u5FvdBx3C7HkIV19T5hMxJ7nhVpZ78NqDpZZPmJVJdiTOnfz8ZoFmTlYyLJ4qNRbRkjo+ouoBsAw2aQZB6f4q5nvIZ1s2qVSVNbOxx/ebirkxEzNVWbmcH14qKQlFBCEFmLN48s9dzfuOpLpr0J4S8Eu7Dg1w6PRGSPUIo+vvFaa5h8K+Fei/FI+xHXG3KQfLtBkiFH6i9GbsN29gwexb0NGLITfTjGPp/MXF7lvsJYcRt7UPCuIMUXx0P4dowHlFH3JCZfTQb3xFbwsKsHDomFcP4WbtW5CkG/kIUQx+nHmfTVjjS7/AMOCtrncJz8j1gE9q2tcxoP6bdcz3tbn8HYwauGL61CKQpCEkG3zRSLx3gn7RrxE75i3B9gfDmH7lY7C4jcEHbySuiR5cfbkRFt+0+3t/wC9png7eVuuZMsQFuHJNxjeDGUrggxxjzI8zMH9RWVOk01/grZdfxNmvvPMebva9xl+bgJK+sbokYyR6Sz+KrOQLXmx5jMvc1RLWX7fBY9/FhuDFjzwnFrJHdLa/HE+tZPUH6fcWHDcnRbM4Y80QRBZYyH0ijXL1lOdNbqJeuyfzmw9y5Tmiaeaq7aGsJcusnpjWfOG4hujiOVyPmMwgx6S2lhtpIuPg/ES6Sn7hVA5mZDCIMnVWbxVYaNtrcEy8oZFtC7Yf3MtY/eS8hYOByRS6fqqIXSfjeQ951nJYcbkICv5iaYJxJWETis9Yu3mIzeEHnL8TyZgkj24VIZrpkUqmvnPyK2c6bPG3lyxg0MwZgGSMhSJ5ufsJLljJwQdAvim8hCeoub23djWEo3xBkytP0l0jw682HegNoTTK3HIOT1FXekp/PxrafTqa+dHvDcDhX3bhyfukXSABrDl9NTCtmos9mbgHRliGjOTnkokXqHSJdmPweTdTp35AOGHyKwIq8xEHCQ0fHRKPuKwIR/LIrtWg9YXApMMP0kZCP2+p3FAhzfuI2DYH25IpCRIgIRmL3VOT6iICzrDqDkGlhXFX6aiKGGjg2eRRAeptga4h9SL8pDmZ5XHRXEmhgkDJwKuDUkQkE8OppIMwdPpJwYAzC4KxocwYcvVQCcwYRSdNDmDCKRMDMyS/cy1WZmQIummAnMGaNBnDX+5RGmhgwl1FXCQPT9qWWTnDN98mWh9rObz6Q04Oz9ouOP6aDMEksdY0wF8MIsusiDh1E4hHF9yNDmzvP2ummGFfJ/r8lGWh4c0hE05MkuWPLQ8M3qoLBmZ/CScf5iDMGYWpEnBWcJvJQhzM8rjHmypgKzBystVw9P/ANE0hmFl0RxdNVmCOOSRAKzBl6igQ/rzJUweW0ZijroIqwhJFwaizSgK9gSffr6qsCGsJdNGGDR2/pqcnCIZI9VKBXyRJSSbcvp+qiA2z9/gRgQ5WmKMSIhmKOMa0p+4Bww6lBBqQ5UhB5aIMEgS5moLpqCDCIhK/wANYHo5vvCCO24ybkjjG/bkGubsuO24tIOvpEy5F1jfxbZrXbyUZQxEIOTtLk7zj9/cZ65HAhxrzzrUtdNj1n4fp34btFnuQzWUellR+qoHfkOxNSDuQPfbcQ8sgyROhemRZfDZie5lwff8G621/wA3bSEETuDUXGzaT57Dq4Hz5uwYk3G+G/epfh3i+bq2NyujqMjgkhBy9TMjJGQnzF0Sw78Wu7jCPubdtu9tOF7WIkox8uMTYoydSMcchMzU1JBrxPu98V2Lt3pSe8bGK7xZYyDyvxEHirx7YnvzolDHD5W3TzOkp9Or05osukw4U9t7QxVje64qE3dYgvhX2XJJpC+mMaX+/mLNq3IPkbvKMklZJNT8TU9Qg15XwTvOxHiR03dXUkpBdAY13jdXZ3d+K3kGQQ9QirKZNOdF39N49c3VGYazunF1dUfECGSMkhCFKQmpITqR6aT23Dc1+H55ZdRawzMdtsw6AVlJ/KVeG7aP3o3jUr0p6s40tc2kNhUjOwj0tNcf3kYVolIMlEg16QeAGZq3oJLprk+8gIDOiDHKOJSMmnjYlLyPO94wTO6bx0Cjk1F6Q3Vs2gcLtxkAKMo441zc1hhdE/LXSMKBrtuHBgkEQglGlRnNl9gPd6ztV+vN0tRDlZXRq4IS3kJpFGTUGRL/ABpbpcR7yPDJjCzsZW2IHVv+H4Mssg8zLJ9Nc/3qYqow3fveIyfECy3A+qUfcXTN0viurvDUYD0Cv9vEOSMmq17inYOdP0p5FH1Lpu/H7/R8f79hU9y3aOLU0x3f8G4kE8GRwcbggpY+51Mv5i3GCd2OIN9m8bBeBLNeLti28CcM3JLs7kKUQxkGQj0hCZg9P+Gvohvh8NPhp8S19JiDFWEcQWm6Ck5gjAhBSk9SNbjczYdyW4G1wYEw+9E3ftxyEIOUrrtjIQmYunr1afy8bisb4Xvs+dHM/GZuatWMMe2u64ffCZYoa/Bc+AYxldD7ZO4sObcniDCuM7fZsQAZXJ46jz7K45kQvUIPpr0Zire0xvElqa4fbMZR5Y45Sl+osuYBDBbsaBitDcpB5gx5q4+s50o9Hw/+Pj8JrL9uN3eYPwlyrQbl9dBDzDk6ROouF42w1RYSkHwRrvGMORtpnBAZTcpOpqlXB95Fy5x04IMgiKNm0nwnrmj4+ylNlGLueSLMry+2ub74Hgw28enJJGugXg3UrjjWHxhZx35+OuvMbizCDVJJJp/red7kGgLpw+fVlEMXcXSNwNhw5vOakHXGNwImWMnVQeMNxzq5MCOiSx6kfSU3A4Prw3ftPMkSq0XWD02evY6xjzAbFnZh0AAKTTjWX3A4D95b7hkjFlOBj/MGugX558K4JGONqP8AFWo8EO7clyx4S6ko/ZScyT+WtumzpTI4TSOpZM4dPpz5vVAWZAi4PTUMHT8mllpgYJACH6qrgztP1F7DKWub56tXZTYDhIYQ+CLuRqBCQyM223KHXRqKzk4fSWdhQMIVXycxZEw2s6wikylOTm/cTADCH9WXmIiGsxRj4yKwwYfSRARQ7JKK0sP8H9zYor6Ak20bPIRRMD1UYP1YkOYP5qaGtozF4+ohzBIHp7CRJWwwrMGuXTJGhzh9NMNkcRMv5kiHMzHqZSzME7wMJSEoQ5g/45U4NtmGMlYxFIhzBm++RGwE8MP381DvA1ypwaNLzCm/czEwF/nMLTIhzBIYpCEGVMDM/wApVvAwxkGjaCcwf+Mvy0OZmSUnHQQhE0MHuSRocwYkAvKzm7qHhJ0x5aaGCT5SrCEYcskqYC/k5vSlQcMOXRQmgQjN+/EpycMlcibOhZOcXUU5OF1mDTCGYWZQq9gSBLJwDKs7QVmDMXLylDM4S8GqmENeYRDw9yWT01qA5g5vaVYQzCGMmaMSYGDld1SHM+4tKAGFmP2qGCmAQ5v3FYYP7hCLcFcOVJ1FPIYRI9RNDM8ryIczMko+DT7iWbNh98FuG8wY4HllILMkXCwh52/E6sXcXpjFdiHfrC4B/wDFDIMfzF5nMElnxk4aOxxEakjJ8xcd1+Tv/hevfw1uiYVZwij1e4NK8bbt/fwtDML+ammD7xRp6Yy/uLeWd41AKOuMvbXP63oUuf8Asec7l4dD3J0OiAgiaknaQdh8KIzOiEI0y16sCFiYJCcApFWYzEOnF3FnX6HbJ/4OP4P8OrSzikoHL011DDeCR2EWmIUQ1WbHjVmWOQUaDuWPKDaH8RM1z4ItKd/tmlyCN5l8cSYYPF8UOuvpLBs78e5XUdFa3lnPWGNRpZI9J9jeX4wwsJBri+KjVmfkk05JJFvL9cnAWpBjl9Rczxhfhs2pOMeYJGRm95cpfyIG2kNsy1rLaYnIQSCkjXO7DjYco49NbizvPeXLkGMZSdxEqbDciTg/ijtF1CXmwV/Dx5gydVeT7xvgxNufvPNsQFJbxaY5JIh+mQf8xfSDFWFWOKmpAEH8RHprh+8jw4NTNRk5QRRly4yDS/box9P/AK3A8FfalNLOw5G4tIyeoSSUiaF+0+sdzas2ltI5K4EMY42A1oL94ObGZrPWxbFcduORZs3hLY2F0Qg2MXpjHEimSJ4XN1TdXvyfbyLo3IxoI2ljjGTNKXuSdtdwv1ytWCcON6yEER5HJqLzfgmz3XBJRgYgGIfprQYktr68i+KrIVEskvI6d30+8PjbfMfEl0IMdcbftrL3h4d4IZKyCET+Ko7w3Rbik464/T7qHeh95RjoiylBrXvoXSU5z8ZW82/CZkRCKuz2egzoYyUdMhCEIiLl8YWPKk6mWo8vA7Q6HRWOX5iP40HGnso0mNrPRbMEZgxEJHHH2ly/d7hua8EroHEORbTEjO5YwK3oooEJn3ERbQDsLDkQEEVwX9ojzUqnk8bpOFZyx/1BmwqfFV5G0aDklcDG3GPqkXrDdLulBuxwk3aUZjguY8J3SdtJ/DTur9zWH9IH1ETh0ONuMg9IfUXVDM6DFH1cyQi7b4f6R2eSjyr4o6/v/wCPMnhhjIOjL9RWBDRMTqJgYOX55VIiBakXXOEBhDm+pIrDBzczNIjDBylXD1Kx6SZ8gDhmF6Yu4rNuqPyZaMCHK08sqmwM2X/DQAYQ5UkYlIf1fcy0ZD081RmEYe5Il7A/mgO3h2KIwYqNlGz2D/UomB6uMzJL5BoMwawycfVTQwfzUOYJIhx6iX3zMJ3ga/Zpoc3AYRE0Nxh1B/UQ7wNZumJYmCswa8zgiQYWcxcxODBQZgkM6k7SzrBOdmOVDmDNppw9ZjmISTLQZg1y5aATmZocwcngrTg4a5cxVvAw/fRrBOYE0eZpIcwa5cyMSYQ5pIx5ireBmF6iYCswKzScGn1EOYJNkYxjlImBmdf3yIeEhkwAzM+nGhzMyBEmhg/4CZirgmF3EAvNbaNOtSHTkJKRGGZj1JFXD1Bxl+WmFg+TmL59Ttqs1tr7iYHCT9+XuSKyGEXkJmLSgK4fZp5isCzmTCD/AMVNkfsHxrABgDlcZBkjLpqcmPYXzjTTk4ZO2q+TzZK4o1mgLzM83yIMwcr7mqRPDB+khz20ft4BpRsyMwfiiSaa8j74Ll7u3oXQg9MrjTXsQzIcvqLxf4iraQ28G8EoHEQTjTXN9fp9jrPhev8AyGgwrjAewo/PmLaW3FQ4pKyFXnfDeKqwi7hFvLbjaEX35Rrkp1etypPm7YLHgwtZKK8xYPFW8I5ikrkJIUhBx9JZO5Y8HysY640rDciXl1qZaZsKpMZcnl1uXnn/AF9NaTd7fiBEMb4mZp5irtrNrbW0h65SJPja8AvDUgx18s4FmNydoiNewrY6RbbwD3yQcgpBZn012DdjiqxvGkb6uLL1F833m87HeCb8Qb4ba7t+4AmaIa2mG/GN7tt4xnJEQQ48xRvbHuPemKrxYwtXBBn+WuF7zr9zmWOtcDxJ4zJm3GAkpPTIsG88bDEzr4p2QWZpjzUuk+9mdJ8HqCwgGZqSQkfbRlh3nDsL/lJ1wOz+NKz3618oxrF+Hmquz3K64kujc45BNyk++RLlsmk0pPnN60s+8Iby6DJ3R6ieTAuTAlFdAidSTtLi9hZkC1HXQQpXHqLYWG8ECLMkkL1FY+lPT+QqXZ/G6ILDbV5GTKKTuRoe5YJtRhE8g5NQhErDjAjNrHWTMFpoc2KRm8lHzJCJdNZnk4B7xg+1MhE8g5PTWLxUYAWvBQNNL/iqbYTMKUi5/iTFX6iecfy1BpRlm8VPKDOicFCzYQ/FEr0iIi8XgZnWZJ9NV203OG844/mKPP8AdUZHtgzGIErglY0ww3Z2Lx1IcchPUWbx48IzulrakGQQ3UhJFpLCYZuXj1OojIp/Gk9Nn49hhjGw+8mDdjQQrJvqEINbDw37jaMb34b4jQg7OwJIQhP7URK93uFa96mMm9qGQgxlJIQmplr1xhXBLHBNmbsWIxCbiHlx9UncIr/onSe+myjlvijrfOc9U0hGFoOjTGLLGPtKvLi9RMDBm8igWcwo82MS9DlLW8vpXZTZQHCQ0eWpBCLgrRhg1xcFCsCGgzSSvNTSgcNYdPqqQjCKQlYxdxNISfTQfu2YpCao0ToAewExRxqyEhhdNEcnQGSjTIiAhlQYX7A5xMxQPAEQ0YZn+4NWBZ1xSdNLLD8l/wACiNoZ7eDZqqJgep4f3yDyyoMwawyE0hph1dPLUhmk6o1F2JDP8mfnyEIfLj01WYPwqaGDDJJRq9tDw/C/c/UiRZXycKrMzrMmBgwj05UOYMIvuKUCswa/8YyD7aDNGXUyk4NpacSXmCM3qJYLzM+3pocwOmmkOpqoeGH79GWgF5gjl6iDOEeXqyJoEOpmIc0Ye6iX/wBAVmB01XCMyMMH2uvvxKswRhF6ikAvMFVmZ1hLmViRhg5X3FWYM4kAvhmFx0ZigQ9yIfyxphDCJSHqUdVMLL4fiiV1klVgQkCLTESVGQ+wWWNQISZfqrTWbMGANcfAP6asCEh/vjy/URgQwlUMHK+osa2KKwBJ1FIIRRxyj7fVREMwlZDRmRkIXLRQsHtZ5WYT8RBmDNs86aGDMEfHpqAZzSdtLMmz/JkDsIOjTXkPxXWD3PvpuAyDF/SjcZBj9TTXtDkxx5eavL/2gRrVz9jPRcmQrxmD5eTNKNVPVsbvx150DNnPIeY3gSW1+QYNMsieW3jMIfc9NWGMO5NSZY8rtphhUIwikyiLidb1mVWfvxqwuvPLmrQWww7aJuDM5go5BkHpLL341bzHjcfTF3EZfnY3l5cUemOPL0liUmcmrcXh5WFgOuggnPTJH0knNeGhuXG+AUbcpMskfTWbttnfM3Tg4BkJKPLGQmUtBYLCe5Cb82xlHlxjkizJMxSpTmjd9WLx7bWNhxGOiutyWUZCDjzIu3J+X+IoHcmO/XkdB2JCtyjkIftLrht1b6zNbW+t0QviJLhJmldDIPT+mnBsEnC1eHA0EQgiDI31JY1I1TRvqKOJ37wi2baJvWCsr6WQhBxkJEMfUy08wT4RcMXjDjd37qbDbxySR6q6IzuT6wvxkIBy+tbWQjiTpEj00ZhXEh9lmIOggiN34yEcD0isCEHp/LRSUxKlGTsPgzwrYXRHQGIxOBdSNaQO5OGMgySRETRmZiZqMg3whyxkj1RCIPpoy23I+JCDzCNnDUgyEIQeUX6Y1GpIzaXhDXYWsZKxfTQ/6SECWQZEZiTa0uQnAzkjIIZBrneJAvsKtCEozYh6aj07OCdKjcBxVXFqEkS+5YqrNsk4ySCWDsONh3gRBkIIUSrvF4ha+Ssv+al+NJnU0xJjyERMzM1Fzu/Y2zZCRkQd+vxDSZhZCrLvA13J1wSKDUytWgDfq3huOT5g1rMNho5rUFGLMkJpCWPsNt5Pz/TSvfxvC/3e7kcQPhkEIhW/JN/SIQn+WsY0++/yUGdXshsNN0uKgeKjGVww57x5IYnklnOQeUInbJ6ZF2i2+CfebzQ2pwWkTcWWQ5Hkn5ca83/Zs7h8TvGrfEfIlHbyuJG5CDilX1ksJveVhZkzJOXHIP8AiLrsbokOfuOJr8QZEPHNzPcD4daNzLAjt27I9vDoYxkJpxD7Y10wLOHYSvupgYP6vJRmKyEcXprpMbGnOeubl83OpemyhOdnm9pQIc3MrImhmdZi5mmrAsx/cJpqail/JjCWTqFUCGCNMAho9kirhIERB0RIAOEcsanJw/uCTCIcUeXm5irMGvaKNALwhIIunGrDMyBL58ohdNGBFA6U5OH7+aRBhWa2zCGMkox9SNWQ5vpoyGLydpWcpCKQeYRAC0B28OxRMKGnk2KJesPS8PykNtDlZkSaQ5XaQZwVh00sF8M2nl5iHeBmDx8aYdXgrVZgwiWJzBWYOpXxocwa9OvKTA2T9VDmjMX/ADEawVmkzEGYJDC1CFTQwZtklY5R9RVmCmbAV/rBt9NDmk9uXHGmhw5WZGh4c301kFZgkN6aDeBm6aYGFWEvVkVZg0BLqIBeYNHUHqqs4JssiMh7ZBxqswRhEQkeYmArMGuXUVZwdPjTQwP1echRZaHCGsPqj9RABmCQwuoVVmZ0dNGbWebJQpDCXTTCw5rZRpqwIYSj8iMEGbZGT8tQLKiWQlaDJh4JpO2oEMwvlIgLPN8ko0RDm5kn8NLLLwh06+mVEBZjDpkjGrDBoCL0+oleKsbWbDbDmrrcWzFuLqHJEJGvvLpWczCGYpEvv95Y2FqR2+OJs3EOSQhIxCGvIfiW+2p3a7jX7hjYz/pS4E3IRvyGaKT1CL5l+Kj7Vbeh4lro8tRLwW22t1l8g0yxCH8xNnJBpnT4e298eOT7XqwbvcOPGOBz+8sQFIQYyD0heovlnePFdirFW9pnie83wr54JxJGQkmXJpjXO79fveT8lb58UpC/uSSlj9REYDwfdd5GMrfh/DlqJcrxeXg2TNuPqkJporOevXRXSzqbNj6MYC3hAxhhy33JjWIjd+OQY/lrolhuXsKMg65fTXcP/shf9z/gtw+xsHxOOMON+dukZMq6EJqDH8sn8NeW2eJCWd0SggyDIIkZBkHpLgM7G13e3/D/AFbZj8NjQYwCAN5G6JXEOP8ACXI96nijo3YlIQDQlyeRyRjHKuuX41F+sIycY/UWXv27fk7C8PG2JL6ebGqjb5HXT186cNjB4V8UR8VNRkrvLJkQubHJEUSYB3zXUJRx38RHAtMgyLB3HAVjsN+Gd3amTm3lHqEHKIRPUVlt8N+Eb9dBvmIxW0keoweEEVW0p8ObqMbFn2PQG7HxgYgtrpu0uvJOSSZhJOn/AKGumG8UTVm1krBG4L+zj5geavKYfBzdXj/gsGMbuIkemcY3JfxEZcvDfvUMWP35bcqQcnLkFFH1NRNnjCmDj83aLl4u7wF0T/s+Xl5MyOMso1WHxLWMxYDsX1tcFHJITSKQmp/DXB/9xu8q2uh/0rbRRDyyEZkL/MVZt1m9S2i5p9dba5biJJGduQUv8RMpg0L9OmYj1BbcVYYxU1IBi+K26hBrSYPxIO2tJ5ykG1GTUJmlXiO5XjFVtkGQFoKQpJPhLgQX5ZBozd7vC3t228jPbsOe8rf1BuHEf05I41Gp9ityui/LyTe0GeKmNxdDPRWNs4kJIMmbLl5aMxszAZqR3WSRuXL09VcHwf4iiGdN2OJrU5w/dHTgfLjcRxFzOmQeWu6WG/Dv21uOsbYbPl4iSdxRqUnRR66cKa6OV3PdK+Z4ybnaDIVuXMH2lMb7Ds2pB8Efprvm7gw9lheArrGUgiEFJHpLke+B40DcHFA6BR9xQdRs6ORmNM6zBkFKrLPbaAupI8vuEUebZnUihrlQEROMnTUOkhSqy5XgYZMsepqLWbvfBmTxRXSxtbwMosL2txzrwf8A8UTpjWX3S4Dfb2t4Le1MRyjKQchO0NfSDdvgNju3wk3Y0UDyhxE9VX/RMHvvso5Lr/Up69cw4cBscK4Sb2q3AG2ZtRxjGAekNOMExhakaEkytP1UQzZ85J5Ih9tVvA+7XbckcRNPM7a7qUtbhK17zyH9yij6isMz/cIiGYZhZYyli6ZBogIazfL7aahF5gwiU5MntHXwSpgEOVHHGq4aw6eX00Av2Bm2EJ+IpDqEolL6aYGDDJXH9RQ2THX+IgF5gkMJWGZ6Y9NEbA5xMxTzoMBhZ0GLmRCJHqDVZg5XUKRNNgRmETjVcHU4yE9NADwzFGMg9VTkie31FZF+vtkEiNmqP26aADio2fq41FZXsJxbfIolbA9MADD8v1EOYPUkKIaMMaUQ8tDmDNtzMsa0AOGiLUQ5o0YUUPy0OYMvdQzOZebS6RUOYOVHwCTAwZpBocwaA7ZFvsGsGYNARZdCXvIw+ejuJobJ2RjQbzt9NK2sAzBhzEObZ+rLiJ3EZMMIsxVmDKs7TCswc3LQ5g0ezMozE0hhKhzZxfvokCuHNJ6qiIMGH0lDdvKUksvMGbyKswUwMH9/SIhzBm+kgB4f6o1DBJyqsKzJ0xqBDXpxxphdVYQwlHxk+mrJiagx5aDxVippg/DlwfPiCG3YNyEIQhIxRjXi/wAXX2yWDt2NmcMcM1jvdwjJmSRiEszmg1zZzezDYqa2GSt87bDb9QhCDGvOfiK+1c3T+HV04tTq689cBDkINgOX8xfGvf8AfaKY/wB9jpx71xG+GzKQhIBkiEJcDxJip9cikdu6ykJ6hJClH8xN1K2udTn7b6WeJb/aBLzipq8tuB7OO0DLlt35CSOo/lrxfvg8ZmP981rG0v8Aia5Pm4iaZHBIlxc94IZqMnUL2+2rGYazOhjGT8Rao1KUGXK8DDJXxlj6YyIews5iuK665XBcxwTtKt4zoM6IQhBcuLUVjM3ONSD0u4PupiPrTnGIfJQMZSdzur68f7Oj4CSX504324nt0TcRCMsP0E6pOo5/lr53+CHwovvFd4kcP4OtwyFG/cSPCR5TBv1F+njc/ultW5ndfh/DNjajY2+wtxtm4xjyo9P/AKij0WXTcbvpsaQGd9z6fy14f+0a+zw9/c5jvA7T+kBZlwtgMuX1B+ovcAQkiHGSOJWBzi+eMko1W5WNOk+x1uDnc4U8b4TheOwiIAgyiIIkZB9URFqLPjaj3C3HWCWIkUn8Re1PtGvBaxNzGO8K0DY3D+2NBjynXqfMXhO2vAM2riQEsRJCDjXA52FSFHqvSM6eVNl952FR8q4JahyNyjzALkdtxVamZXFBHxWRBdN3lRLulzvFquXMEAQkgumQmauZ4qsNux4/cMR2rnSR/iqNLJpN1uNm34e2YYP3tWYA4/0gbCeOiDHJzHb1FtA4q5NpxsbzzI9SMbzKkXm/GHhd95P3DppanoyCy4BrDm3Y3llIMZ3sjAmnmC6mmrGebT/NNp1K/wDJwezP9+V8vAh0AdiGMRI8wgylWPxVfrjjC8/HXUhG4tMZCZS8/wC73d7jW8cwMF5fMYpB8B9LM+YuiW3w64mMUbp8d7cm+qQfMaREumbkf5mf1bs/sdIwSHD9h++P3vdCxkGMebEu6YDwe+v7UZHfwzfUGCMeUuZ7q92I7NZSVjO2ZE9MchSrcM5wiJx3gvLl9MkSg0rRVZGbS/582o3hbssP4pszhjeIijjkzCaSw7Oz2Pdi/INjdXz1uKMbdhzEsvpjW8ZmouTUZDj56IZByRpPcrlasHlna24Q3Be23kKJQ9vqi624wreK7Du+JW7oEJw6zCD7Ui4XvCxhzl0JHWtJiq8YjvtmI+dtCW23i0yH1Sri9+vxDOnA6K9VTZUpzVtaz4eQ0PiSgP74lLDbX2PLyNoxGQhCkjHGk9tZj+HI7rjlJGOPVKTtr2x4P/DqOwsG98fNOWIUfw4yaolY4WDSlHN9R6vPg3HhF8OoN0th5p0P+kHQ8whF2BmGu/OuDjjbiS8Jj3IsDUZY41qAs6LOIY+PMjzF3eLjTnPW4XNyqUoICEYQjo49LqJfja2juVhcAIQvLlHGTuogJpix8Eql4DK1J5Pw9VSUGk3x7sP2jWOPBD4g8QYAxM+fYgw/Yb4QUZHBJY5CEHGTtxkGvqh4XfF1gfxXYNb3HDN8G+IKORoTVF8wa+Qf27W70eCfF83uvKkG3xHaxknGOLMGQg/5Y15n8OviKxN4dd4Le/4VvJWLgWpR3R9siNSlpXso/TQEJA7OPgUhzf5a4X9nj43rV40tzbe5Dr5a+MG4x3Rp1RE7n1F3wwM3LozNRCylXZMGYOaP0lXDmyE+mmHJ5sfTUhrDloMkXhDWGSiujMUNnC4BjRAQ0KwMZkGAyh/4IlWENfzJUYYNcqkBOmgF4WY9pctEQ/8AAiDB6g1Yb9Yhk4EsBKPu7POL8NRE0NPJsUWNYeijhyox6iDMDpphDWb9/MQ5g6fGkG6i82wgS5lYo40ObjlyyJgYNfNR8A0GcPpoYBvA+2PMlVZgj+YRGGDDp/8AVQ8OZ9xSADMGVBmDN9yhNDByvTQZuMMfn+mlgvMGsPcF9RVmB00Y8Dm+fUQZgQi+aRABnDmkGhzM80ZO0jDapBqswc3Ui9Rb7PRpr9S+LqRqs4dTyIx4GbZGq9oc0nSWZtwcNYWuoOP81SGbaTqeorHhqwtSEoGVyTpjGSNWbdntakJ0xeomNNgcO2byEzMxcP8AEJ48MAbgXd8Y3W8xXizN+ZjjIOX0xk6hE08ZniusHhR3SvL5dXwhOCjjbjHmFKQg8vLXwb8VPiixH4lsbkxPiZ9zLgUg24yDjiH21JnNSdSzdftuseLv7WLGu/JrcGIHxLbh91IIjTqlH05F43v2MDma9SMuoQnSUeG5x0MHHEPVITtJWb+krySiiuUf8tS3NUrSnPyA7kYhnTegchIswnqjUNIEregYxyZZCSfw1ARu5CVyySZhPTUZGzSHIAherGT01HSZ+2Ms9tac+4G7ITlxN/h4+qQfTVYdWQ+UMo8uNDswkZtSD4IhlHJIrAhJbRDoGPMyyLSlew3XTnwEc4MLUgwDlHJmZmrGrAhOEsdAy8wL1NInbUOYhhSEIIRMyQZPUXrj7GfwQk8Y3i5t5HTEpcJ4cGO43QhNIpOmMnqEzFilRKdOfjfTD/Z+/s/T7gdyLjeHidiUWKMZDkbjIPNas+n9QmovpAbYT9+Qo1XYbC1w3Zm7RqMYm7UcYxjHpDH0xojR+4Mqjuoxpa5hzBVgTQC849VSGjMISNTpdISKpXpNn96uDx42wY4t1fVHlk6S+Vfic3JuvDrvkbkfNS+48RkINuSPqdtfXAxphcEkUq4X40twLHfluRulqPGN4IcjcmqURB6ZBqpzsad5rronUqQyHzfNursFyuk52LYjgTeQcagcKgsPMHHahsellpWG23zd7iMdqurQja4MBxtyEJlFRGML8SVme6jKSXLIMZNL/MXE0l2U8j1XFrs9Nk6LLlhVpchuKASleFy8yNZ+/bmWvuzgHRE3dEkjBITMVdtxsTB7sYKK3JLeUhJCEJIUWWPqLoFtxsB3ax1gdNitxDjjGNbzn3rjb42TwTuZtVtFnsRvSFIMfAfKEL8RbwN4tVtKSgdA+YYZcnSkzFl79iQ9tKN1Q7kb9saR37FVfIN3bUn7UQeYTq/6jWfkxSff5KOiM/c2MBZbsTZwWQZCD1UGbc+cz+Md5EX0yDXP8NXhpcpB0Re8OY1B9X5i6hgO5HM0JW+PmeoTSS9fDmrafYHDYX2Dwk5uJ636ZBj/AIg0vNvas1taznjG4ETuJfvI3hDsAnBJy5UenpFkXlvedvUGG8vOoMpNQnS+mlemMXSv+x3jfZ4ih42sMAziG3EPMkJlLzneN9jENwGxsbUt7uDokbeMeVJ6fcXNzGuu9rFLezWqV84dEijH219IPAf9nI03SsGeI8TjG9xAKMjfLlE19Mav8HB73E9TzuynjD+BvwNvgOm+ON4fxN01GbAmkwH6fqL2ZbbaR7ljGUbcWXGjGdnmjH/ZxaY5E0CEYReSj8xdLjY2ubjq5Oyn6iGbOi2i8mUQuopDmjr4Pw0vCaaQYxjFEjAZ3dytONTSTAO0hijISiJQxhhKIfASRDhCQxR1kyh+miHmQ1jIT5ny0zWW+W/+0UYPJ+huA74SiUgrg4ZE+XGMn8RfK8MZhSAy3Hbk1V9QP9o03tDtrXd/hKisRHBeYuzgepFpjH/MXy/ZmAB1x10S9sZFnWocn83qz7IXxX3Xw6+KrD9FFZC2+/OBsro0H1RkJGP8MkZF+hQJhvGvHJLLmR9VflPwrjY+FcUN31tIQThqQZBk7Xy19dPsx/ttrdcrM3wrvUO2Ze62cje7EIQnNEk0yDzMxGszGr2eN9PIfUEInbUMHuaiHwpipjjaws7qxdNnLN+OQZOkUaYQjNJGT8NKW0i/zhKMeWIZfxVYEVGYjOkPyF+orIR/UQYXmDlZY/xFDAh/cKJEdvVVcM3UlQA5owijjLIoEM22OtEQf+KgQTZddCXrD+R/c2edRXcBBeWP+pRAehDBoCLTS8vBFJ2kwMGsJeMkny0OYOooNKHSLzGoDHXmocxv8Ayox4FBmDWYWYl7KGaw+2TMIqzcZvvow2Uhzdz2pk6F6g8OagzhIbz0JoYMxeOND/1fTTfsal5g+0uYhzSGkRhgkMX01WYFAfIt9YKzRhF50OYPbzBpoYNCD1eotgDMLKJXmqswRmF6iIMEns01XPR7RjImTLBmZ0Raka5v4ovEtYPC7u0eYgv5BcuIcbcckZSk7Y/UXSLkX3bISsmkPuRr4n/bSeLQG/Lfc3sbF8Ulnw4MkjSTKKSTMJ+WpMp+RU9Rzdc3E/HV40rr4tN5bi5HrKKzyf0ewJ0vmLzXeLkS5OnA+AhBiy1ZeL9zjVw6GOWL1I+olbwJA2vz5RCkjy+kNT3HVrSn681cwwicOq5Skj6nbQ4TEttrnrGMZC5Yyd1WXgPJtW480oyk/LUPGEo6KxlK3F1CJFJpEgbxnXbbXwErGOUmWQaYWHCzu/XRvbmlBCuCuBibjHqlHlkUuQZnQ8sXLib5YydVepPAfuHaW1gTHdxGQjcTeO3/ADOoT5arc7O0TW/SMGmVTXRZuZ8HNqwThz3rjGgT66Oo+XYE0mvqEW8xV4acD48sI6AW5iIkkhCA1SrzH4qPEVf3m8u6DttycjZicR5eWl+4HxRXmz4uZ0XWshGZSRyULj61yKeTvd/LFxJ+PsEeJDcCx3JYtbtWr4tybum8gyEHGX5a+2n+zQ7kwYJ8D1wxPyIhuMW4gcEk6pRjyx/wyL5R+KI4MYYIb3IAxk9wuIyE6sZF+gj7J3di13b/AGdm6u20AjJ+j7d64j6pCDkJ/EXR9NydkPIoMnCnPI8buB2ZIkOYP7/TEmF+uTSwtXB3xxNm4hyEITLEIa+d/wBo19vxu28K7B5asIvh4txZy5BjG0JK2ak9Qn8tWUjNr3ZirFVqwfayO7i7Ysm4pJCHJEIQ1438UX2525Pw6unDUd//AEguAh6FtzcxfB/xdfaxb2/FpiO4HvmKno7eUkbdg0cRCEPtxj1F5rvGJHdzdE4z5hdRFZDa+uG/7/aiMY3504a4Dw4xtDcWWMjskhV5PxV9upv3xhihm+fYxcjbiIMnIUDiFqdReL+cri49QiIZ2chmsmkMSVORVMrW+zHh1+0Uwd46rCO1Y1tw7bijl4+bA4jl+WiN5GD8cbmWHNsWJMU4f5gefQOUohr5B4JNdcKv29xYnK2cSfDx5ZV9gPArjC+Y2wRY6L+T3k3dMxkI/G4GKLL6npqNk9MnTyLfpPxBSfrr4fgw9t3qYZxVtcMQEEJw1HGQBOkNK/0wBhsTihieQckkY+4u2b5vB/hnG1qcXWxgbcw6bjzAOIpV5rx54S7rgNqQ7G8FE8ddMg5cztqgp0mnD9ndY3xRDm6BYceUGdEBXQXmCtyE1MpNLPbf0qat3z6NsMWYMEnT/wBRryHvUuW8Ld7HzduG5btRxyNHGr9Nc7D4i7+EZBjuT1s4KQenJlR9NQaY1Fv/AFfHpP3H0k5zDmCbM4BcXY2zgWZIPpSaaw+NvEVarMw4B3WUnLkJIMcsvbXjew4q3o7/AL4G2jeuemQ8cQvxCLcW3wxgsIZ8cbymzGKMhGDD40v+WNZlg05q2vW4cP7zi/eK6hmwbgnKRxGTmJMxZPB25jGviWxbzbFi5bW8rgfMPyZQhDTxnvC3a7seYJhzCors4Fpvr64kl9SMeWsPvU8bFxxIIYD3gomYsoYGmWL8vLVlLprm834j58/HN9QPs6/B/gfdlZubYnY3a8FJI4PIOX5a9gcmBnt8mb01+dfdX9oRircPjJvccIvithi1BkJKIvzBr64fZ+/auYV8Wlrt9quR21kxQIY5GhyDFKTuDV/KXDhNzm31p5Hrw22DL0olWENZhccer204s+FSXIvHqj7nqJ4zweQwo4ySCUlqy7O2kD5KK/b3EYzZk2R0LSGwrD58oaMZ4VrizKMtMBGG2w5fppfiS8MbCJw+uNcVvtbchHBCaQhjWwuVtoZi6YvmL5z/AG83jG/3G7kW+A7M+ixJjIZOcGMmaJn1B5enIhCrXxvln9o14nD+K7xN4oxVxlLb+YIytY+03GTL/wAxefwmmLmaalzeV7GDjgrKTqKMw8m1HXXmkKNZ2KSn3mFtNluI0wDfiBfjAPK6kg0ntoYWpCEJLKSQissJpeYJlZWWNYL9Nb3B4IftbsceGmzt7G7OW7YfETLGfVEPqRr7GeEXx4YK8V1rbgs91F74dM+ZI0GTNF6hF+adkaa4DBJG3EPLzF0zdLv4xBuHxG3v9gupLbcBE+HIPq+ms65myzqTfqICGZ0Qarhh9QfTXzr+z9+3Ctu9T3PhjeE1KxxI6IMY3w4+WdfMzMsi+jjN40uTAZ2hxOW5RySDJJKsa1tLOnzD7QjzPJL3FAs4REj00QJnqdIakM+mo+xNBhD6mYrIcrMVhg1h+YrAM5vV7iKDW/kYaODZ5FFK7X7a9uqosbPRnW70YMP3yIN4HNkkkRhgkN9xBmMSbgorzFW1SZF7yQ+ppquH9XVEjIf/AA6f9yreBHsLwIkKl8PtFmEQ5uAItORMD/8Achyih+Ws09xqHAGZr3FWYJAi00RoeqqzGIbyKROjSoMwcr7mYgzBrTCcntjkQZjfqj6cid4ytgM2d9zKVZgUfURBgzFVZg5qYAZgjML7hJPUQcIwiIQhJItORGGN3NNeU/tS/HUDwc7pRkYumxcQPyRtwSZosvUTJTR611zcL+1i+1WHuZtd0wPhIhRYgESNw7jyhDXxjxVip3fnTh86PKR+4HmEJIXMJmJxvm3nXnfBfrpiO6n524P3Ejg5CLLvCzOhjoHzLgUZB9qORTZ+NxubXZRDB95Cb0DGKMTiNxJ1Y0Q8ZkD5JBcuImmlduNM6eDrJG45gmWNNLaAdydEAABSuHRBjg9RZ2znPZQqcqU9dcy9mYdydcZHZeXFl+f+Wthur3D4n3zX4YMP2p65cP3BCRkb5UZMwchF7M8KP2frHCtrt+JscW4T6+Fj5OykHlC9Qn5a9OBto7DZxgGC2sRi/ZxtBxCKuRzviCc/HN3fSfhOlOylXiuxfZRACwbu7xiflroUcjgbQcv016MDurtW73dUzwrYyFHb7W3IMZCDkKUhNQhO2Rbhnytsa8AMwhemh7kYAZD15ZGumMY9VcVm9Xpf3HdYPRMfE9t8/wDxFeDP39jK4XViQjIbommNvEJc3wR4RcThft6yViEzE4HIRfRi/M6OVHXXQIrx1JHJ0lj3dhr5VwCjLGXMIQY+omS6lz162aYU9mx533zXNrhXcjeLVyohDf3RuOQkZS5Y5CeovrBul/2gPcfu98JeF+B05HfLDZ27IlpI3jLIMYx5f4a+S/jMwHdQ7tGdYGLlza2rghLofqiITLGQnpxryHtMPTrrJIUmZ6q7boGukO/g4nr9Nd3uz7QL7cjeh4ri3C1W24/o/hcsnwjQkco/UXzrxVfj3J04IfMzNTqlWseW1jsauJDlG4kyxrB3KTmu4r/WpMbJ71c1e0Q/PErLaGs0lceWJQLMhxyVjlTy2sxmCOijKHHIRMb0prV2Gxc4VvXXRlpo8MMzobSgcbcShjUW1oQg68sWWNSzhmE3orJmFk5j0lmc1TSuwZfrkMLVmCigshcsZO0Ndk3G+N7GPh1wuO1MXQ3tjkzGDvMEX5ZOmuFzDNfiZnw4hxjIpfjfFNwUEkGLMIs6mZV1valy+1oAbDhD0Wp8xunLkjINxlSRrif/ANoRvDuTUZHT7mRydQa43fgjDZm4+CWVwMcireBB7rJHRliyhkSdax9M31evLb4xsAHwa3960Pn18dD+IIMeUInbGuT4q8RWDmbpxXarGMcX5q4eEMzUg49JJzW2F04HwdSONRqYU6JUs7sdwN4zLqzsPIsZRs+mORc7xHv4vl+KSs5yxl/KWTMHk2v1FHjOFr6ZSSLMpT4CmdsMNt+fPC8ZDlINBvLlW8KPTFF21WzNWZr8pWBN7HRBkTNQ2h5q9pZOoJOMH4wfYVvLe5MTlbPGDgZBkGSIoiDJqJW8DQH7/VVYupwEQkyq+6H2Lf2yYN8zq37vN5r5i2xBIMdruRBjEJ+P+WRfXy24VGdqN2CiQZdPqZa/Gfg/FT7B99bvmLsrZwIgyNyDJEUXbX6TPsDftSmnjG3St8HYmff9uMON43FH/wAePpkQZte8HmCRxZg8xDhw2MItMS1kJLldJKMocckfaQ9+Z1hLwSZhe2mTDj+9q/McB4SvF8upIrXYW5HLgnpjX5b/ALQLxRXLxUeIzFGMTkckG6cEHbxkHpNx6a+yn+0veOoe5PdBb90mH3YvfmLRyXSPVE36Y/qL4H3KQ22QnVJ+WhW5NFhraM7VxQM5ZCxjHR3VDScpBXldNEM47kVvQPKIUkknaTB4E5ytx1jETqk4FmUlJSnkB3i20W1qSgdZen8pEW0NFtY8EYixDlVlyZ1vOTHQeQhcwg41L9wGYN6AELmkjH8tGsraltD/AEWR3lZpNRWW0w3jrj4JW4h/iqy5BHbWEY4soYxx+orDBoDbByD0swhETmNowNyo5uABCCcR6nVk+YvZHgt+1Xxj4dRM7NcnxLlY2rgcc5CSi/MXjOwvCWEo31cfMFJI3IQcsqrDeK7ldOOiso24szL6pFuzKr9SHhp8QmHPEVu5t94sz5kTn28kfMZol0CGgP3F+c/7P3x7PvCJvpt95roK9s+YNw0k6ZO36i+5HhF8e2B/F1bCV2N9E8EOQjQmqo9ZL/Gzp08btAAkMX76ICFEQjNskoJKrIawi9NLWwWhp5NiiL9o+2VRY1jyOxmD+qOQvcSswc3goTA0gY60ObP+4q2psi+EhiqGj7f4isNIGRDmN7RZiJ/Y3Vm7fsQZskRJERLWo84DC+/KntPGXiFN8tQ36ijy+moEJPaQf1VDcZheRazFA5g9zq9RBmNX/gRhg1wquaYo4xxSqUUXmjCqzBhF55M1ETQ5eqhzRmEmArvzwdttZDyCjFqekvgH9sZ4lh7/ALxQXDkTyWvDjfkh/M6n5i+uH2q2/wDr8OvhBxJdWr4Qrg//AKObjjjlIT/pyL86by/EuV6cHOQhJSEJmEllUnGm5zq1f4y8wZrC3koKJuXUIk94vBOfG7JQVs3KOOQacGs4NpRtayOXPvQkjcYyaRPUGg8bWcgRDO+lFESOMg4pctT1RjT7weCdvvJ04IOsghyZZOqVe8Ps0/C8xuVrcbw74xkuDpxHa259IUfUXlPwc+Gk/iExkQhyCbWNg4jeEo1RfLX0wwHhu1bmcGs7VaiSN2Axsm8hM2PufMXGfEfUpznrm7r4c6R332UdIZmJbREOQkvcJHqpPeL61eNZ+RGWLUHQ40lXbnju8eeugRRxx9qJD3JmM1rGNjlt4yEGAeV9ONeeVrwo9IlL/wAFcxHjpwN2By2GIcg4x6SHuTM94vMbWsoszU1RR5areX188deQg2zcQ44+qkeKt5wLY1b0EfNhcq4y48rp9QiTKWxmlJzaQ2FRmE4AegRXmWMfa9RZu/WCuwunAKKxji//ADC4/vg8bDHCrUY2NyE+cCJGMg80pUH4Ut/GIN4d+cVvrVFZ9SQg80pOmp301OE9iNTJnz8c3QLxgoFyK8w/W1KRniMfLXQkmVp5a+de+DdLXux3oXDDLoAuYtbwmYPqj6a+pGKmZ7lYSQDKNwUcjiMekvIf2k270dtxlhvEfAQTh+zjeDGOUUg8vU9RX/w3ldl9bmvijC2Y+x5DuRgXJq4GQcfxEgyD6qzbzCtZnRCDJl9MfVW8CGBqzrJQIWYTLGOT8RL3jMBnTiOuNxqDJ/LXoH5vL51pNn7bbeT2DkoILpkJ0kwNbKAiJBENwXU+WjDMzhKQZyCfDKMYxxocIaDtSEojbRanpD+WtzPStOdCtmat5dOUIOUYiZhERsNybRxXp/DxKGBWzE4ISvMKOQceVKgzMzvHTeig4yt9SPqrPp/7m+MY0F7t2Nxx+pIg8x4VwfgizIxkRmy5D5ohBkKQYh9Qeqq7aGjkB9ySRYYpQPeBTOmY+OSIZCJga3Ufo44rJQQRJB5agQ1+/nBODSjGP0kRiq8EuTWchPiCuNMY4hIGwPbQ9OQZSZeWlZuD3g4IQkQxOPy08txvissYhZaT+2ZpcOOjVISNBcg+JAzCb6ebIq/ZM1H8uPMRlyDWYrfz5arAGgzVwPj0iaa01p3pTxk4cl1HJllUMCF19PMVhgw5g6I8yREZhnXzVg/0Vm+Ma6ekhwhmkJ+GjAmGGQcmWJDmCSMlciNZ0qUVszQiJlrtHgt8UWIPCX4gsN40w++ctnFreDI4GMkUo5Mwa4uE0vTRExA5gxpaTtfsr8Gvitwl4sNw9nxxhJ8J8zvA/aePVak6gyD7gyJ74g989j3A7sL5i2/uhit9lZkekIQkftj6fzCL8x/2Qv2quJvs997TiuN9dsJ3QcdwtvMEiKTpkHJ1F0j7Vf7ci+ePbBrfCNmtRbBhcRJHA5JCuiD7n/TTdZdMmbzH9oF4tH3jS8S2IMa3U7knvRwQjMZMwQhj0xrg+ZKPgrlIKTyEVgblDl0URRD1PmKbAjM6bwELHIMZCLE0GtPG0FnZzOuB2Mo24hjGMg/zE0ZhreOnB2g5MyMkiswfx21g4PWDmRlGQgyfM05ER7yAGwuD1yicdSPuKTL21BWnkBhN7zvzij9mJpt4yZXy1YZn7yvzg5KxlbiGQbiPSkVlnZ+7WDeQfMtxDI5kGTSJ6imFRQi4yZRHRJHAyflrBe0G8ZzXRuAZOZGLMcRqXg1BnQ2g6JZeoPVEP1EwtoZmrg8ETwuWMY9KNK7bx8+R9micCyxj7o0N5JeDVh5drRLlfDDy9UaIMEltjAMYhD1FLaGi5P3BKySt2A+p+Wqz/wBJlGAhCiIXMJHpJGv1NmYW25VvHRCV1jG3Fltx19Vdg8IvioxB4Xd7Vvv9qd5gstwAhMoo5Fw95ciW0RK68puLLGMg1ZbQwxnPJzBR/DjGtzZeN+lTwE/aTYY8Y2Eo2tHLXxrGNw0Jqi9T5a9OBDQYXHRETp5i/Lv4RfFpibwx7y291sb4XMCHG4H0ij7a+9n2Y/j3tXjG3fEacZSYgteZcB8vpD9NR6TXeDnd/jo9REZ18e3S/wDqojdtMvm4y/rUUPyLr5ug3h5WFpJHl9RDmMMwuPpog3B8z01WEM0ii6zA5jIM0YsuPLTAwYdvnQZuCJOAc0gREGh3ga4hjHlkRBjUTIM3HmVjIhmQeb4qP8NWGDCLgVZjTGk6camzjDqVrWZdFZ9KNDzk6aIy/wAtDm2DijUpgGXOk40Ob9l6UZURDCX7+WuN+NLxLMfC7uRvmI6yC5wTcg24CE/aidMaxOaPWvDhN84/9ou8SDS/XTCeBGNyHy9rcEe3QYyaRNMY/wCIvk3fgUXLl6x1yjayEcE7RCdNdA3/AG/J9v43oYgxBeaxFuF0eSEH0tRc/tryZq8rIMQnEmYPpFU6f7uNyaUpQZbb9XbHZD8iKQo428fcWX3hXF8YpOePK4F3MzMTC/XIAWpK5PiGpBky9JZ/GxqIhnrkGR0SVMyaa/vSumS76PTH2bOPBhFcLPlDcFcSDJ3ZF7wwrbZhEruQCkIIgySdJfNvwH2F1eN5Yzgk5dqP4gg+qvfH+8gYWpCOnwxN444/TGvKur/OmQ9i6ROc4No8Ce8OuOcrYeoQfSL9ND3LeExw214Dvo3AugNc3xV4lraFq4dPnQhRDIMY9PLXlfGHiQxNvsxH7qw4ApcwgyHjyhKBPC580mmVw4e27Rvs8WY8B2FwBoQXMOiEyx5kq4uHBO8LfwEZ7jWW0W+PTGTVGukbmfCWxZlt91v9bm7XQpJCDJpCXdLl7u3bYR57lSFcCzIyDyhDTp0nw8cytfPn5KOL7sfB/h/Cj8dxuoxFIwGQnxZF1yw7wsMYWYN/dVA20pIyEXjfxLeNh3iW9OGNtJHFl5ZMpcDDvUxHzQyEur6MRJNRWM8OnOfkRvrZ8Ka5vsYYw7lYW52MTkcgyEIPuLz/AOPGzkuW5fEBKBlKSw3QY28ZMoUg8xOPB/vCfY23fW+6vomzcoxtuCTNKRNPFRZxl3QbwGtEnLlGNyP1VDwfHkcBm+TD5vm2GcPLkoOLUzEGY1BmpCOxxDK4yyD1UZeGdBnTeuisQvQ9TtpezM6C1bjICWVxlk7RF6zF47Wf6mBmcJR0NSDEMrfLk1REVZuVeMHFB2sRCuIyEVYjNbleSEJLzH8IgxqBMcLXmyZoy6gx9JN2I06BzBOHyVxklJGP5arCzo5pvymW45ghBj7Q0wDbRvHRCAyiCHEMZOqQirvARs7oSglAxjEOMZB9xajYR3i2zcvx0EFLmRydNVwu4iEAeXlemnAQ1nK4O1rK5ijH/wC2qzCGGQf7E4KQY5PT6i11JE6E9sMQLUnHRqkky+kptvFBuTakyiSfhJwzttBnRBgJ8OVxH6uWl5rYTmiHjHy/MRyUdxaszpMRbHgGZXFZziyu31UGzeUAYEo49WQkiINZyGEQZwZemPpyqtpZyGjGSgY3AiRjH3RoN8Ze8eAMUYx0REVc0Log8vNHqDTQ1h+KJI1IKUkcnd9NWGsRzFHQQAyDKSMfpIbzrMjMYnKx8BJEP7Cc23rJQWQXUWgttmfPCD8nw5ZJK+kJWBsPwshCSDL1EGzyZs+ZnWYRK6CZfy+ooGwzC4+PLj1JE4DaB22zc0SuQZRycHqKGtlDRiMckssY8vpSLTX6j64jNbThayZUeXGrA2eszofnFIUmWtR7naBdNx1kKVuUgxjjVgbCx5ochBSFIQg0ax9cDsNtfBdN5KMsTghI+6iJj7GshGnw5W+mP1EYGxOg+fmhEcCbyRydxMAhOzdccgiyxjIOTSUmc1bTJox94Z1hdEHW0j041LOYAZKyD0h6a0lytr47VwQ9AyOMwgyKuzswBEPjaZZSfEES9Rn1PjMA22FqNjQ+jlGMYx0empcjHC1b0EaRSkkcD9NSFqYo6BkKIjUYyDJ3SEUeGmvJHYK+ZI1GMZBk6q2Qv5Niy5cBhkasTlGS6OBxjGoa5DMXPGQRBfDSD7ncVYTDNeR0EaciMWmTukVgTHM1Z0PqBkbijI4GMel20N0vBh2fIjlIIccg/U7ireGHbbXBXWIXKjkk7snTVhgnZuhkrrGVmIkhB9pDh4zC+KGLk8whCDHm+mlgQa2120Qx8AiDESRwTSlGl9nFQG1uDkzCFyxj7SsehJcit6CSDcOiRjITSENS/GGEXGOLtjGPudxADs47wJxqcu1zCDIiHjwgeXJR24x+kqzGBbWrcFBNUcjjpqWEM3xxKMspIhoO/wDcYEPu0WXR8QXUJ2l6E+z98aeI/CLvV95Wp8T3eWP3gPuj7a83vDHuV04AV6WW4TBmasMg5B8uLUIMmqlmy9X6BsH/AG2VtxRhpm+tuES1sy0cNFRXHn27adu2ir2//qp2qL4c4T8RrnD2HGjKh65HS3o4eH+79e32/wDqohK+uo/X4aP2eRBmNP3NREGNRtERDmNmDrkEqt14cxiGLH/EQb02bmEEJEGMPU1IkObgNmdPpqOFZtL76DMaEo460ZNX0yIMxqDOyZY0M7VYY/uSKHCPpqByPvqGkMIi2n9hVA5jUS5hBxocxcrjo0y/lKwwRmFGT8RDmkCLj4OopOwEe8LGzHdvhh5dXxPh2DcjlwT0xr8+/wBp99oofxgb0HFYBvWOG7DINmMjjKKTufMXsT7eD7TKiwtXG7LCt1IO4CcR3gg/4a+R9yMT9EhkrrGQhXEhB9VWONNy/Vs3ya5s2zwqO5Rvq6ylJJJGNPDWx9zVw+EbF5puMmXqiy0jDcvcToZzu/hyjkGP1FYC5DeF96gORsQQ4yEJ1U3aqKbPcLwhGYRKCDibx5knVIs/fpPcw666ySCJGMZO2thcrbNy5+bG+lkJIPpLJ4qZjCVw7oIUgy6YyE6iVXyLLBr5HpTw64ws27HwyPLqxoKS8FkG4k6RE0wTuZ3jb8rMN87upWTco5G4BkiFGsf9nLg+242vWILVdRketyx5cmV8xe7LliS27pbMMFFbIZBN4xyDky155n/Zka3qPTad89jzXYfAf7ydD96u3pMwfMEkXoTcz4dcM4Da8ixBywxEIVwQ5BjlXE97Xjwt2G/hWpG0kkhI8qVcvwr9oEfEmMreN8Agm5XA8yTNEq6mNkc5p22HCj3xYQNAv3lcZOXFl5GrJ/MGud7+LPdcVbubgO1URvH8gxkITKFmdRbTdhioF4sLcgxyOCuJJCaRVZvCxI0s/wC3ciMmmQY82IZCZeWqiWzhRZU10m8T7q/s/Zro396189cCkkcEHpCW0D9nVark/cSMSCGLM1Ihai9EYV3hYfsN5cAaEEQgm+YMZO4tRcrxNYW44JW5R6Y+krGubkIUsLHZfdlu+tWD8CDotzEjFva3A2zeTq+oMax/iQDXirdfjgZHbJjFaxkkISXMHmDWwxViprKza1jI2bikyx9UncInFyw3bTRjYsWV2bv24xXSg+aKPtpcqU4U4UoZky4c585zfKt5cgXJ0QBJCOI/qiJ3JFn4KwtW/AcZZXGZ6RF7E8RXgDIFrcL/AILB/R7qQnuUn7SL1B9wfpryPfsK+7Ct2hwPbQQRI3Azt4iyL0zB6lOjyLO6bSFPJwDmuYzP7gQ7WIkeorLaKFgMjEmYVwMTiTqpe8CfmrhQSuQYh9Tqqv3l/RjeT4bM01Z7FZWX9/BoHhxh5Oh2MnMCcEIMg+qNVsw1xN6KCD5MoyPSDJ0iKv3kfmm4wEHGJvlydJV3IzU5bhllESMY+CgfqRrdG1LLQGgOYeVtcCkIQhB9UalhDWZqOuigZW8hHMhCaShg1/EDGcZG4hjGMhOqq3Zxs2rwdACD0xkTGqy2tKOUGetqXmBNyEJHpZnUQ9tA0Cxb8ZyDIIcjgcebIjLkadgNjQ+ilcDGMnSEMf8A7iMuRXRrW4o4GwyFcRyD1SrbWCuzs4LU3OR8ITeMhMzVkUtpjhtfHWcfLiIRyOsmrIrLjbSBYEHQAQnGmOQisMH+ho6GPxEkeZ1UawHZmds7AMk4xNyyEk6sijM1dts5KyOiiHHIONEXO3D9zDoGAg5SR5hFLkz5y1k5RjGMpBjzNVGsAwvAM7M4r4yFJGONuP1EQ84A2oYAAKWUYxkGQmkiLkzPyo4KBClcDy+qWNGXMLq5Om5BxDIUkkaNbbYDMzo5BuBqxLJzGYQmYrNpjytyAa5fMEkkHqqyG4ldMyErGKKQgxyKswXwRN3c4pBNyEjWo1gwmmLINjl5hCEIPS9NDhM1NtgoGQXw+oQfURDy5Pg2tuSsfw/Lxxj9RTnIWpOaBE3y4x9VDVLbbQG2/CviCcCIMZCEzJUZ7nHzPGB8TlykkcEJ3FGZmLwQ/IVsQTgmX3e2hzbLcZgOuisom5W4xkGPuLbYRsGe7XxmpBzyNxDGQZO6o8M7MVuclA+XKQgxj6oiKFtsvkod5Yv2cfdVhmbtm6GQB5JR/EelHmI2MeNWE0L8g3wJCCJIOPtoezhouTXmwE5ZwVxIQZO2oG5PgtXFA6BFcCbjzCKBMMJR0HHE4E3+IGPqkWpupWYNYLM44yCK3dOI5Oqq5qAiJWOspW7okRBj1ctRmEYRM6ADI5lkKQZOkRDmeDZ7ZKKBaY5B/MQbOXeIMYASj4CFjfjkcD7UajwwAiGAZCCbvxyE9IajN57tEM5IiNykzBqy2hrtrWN0AQ27okhPSGlin7mFu4LkVwN06IXn8xmSPSVfucYbo4HXGIjAcjePqoMITmdRkGTUINnHpIi5SB+EIMRW7DNcEk1UG+gO8B95Gb0HGIRH+ZIPVENEXh4QLUgwDFGIYxjj6pEOzMMzUl1yxuCkjGMnSGmFngM6GR1ERuLTJHlFIhlYG2+6LXHXmkjkIQeqldtEO8P3B4/gxepqqw1yruV0I1kHI/JqR6SsuRicq3AOsYm4iRuI9UqW1/8AzMh4VcPqNhmrUvLk/XR/yUSqi7FBTsooOXhp/qzFEG+R+z82eXz6arNwfudJTZnSZgpO2gzGVW7lWYxNSvUVbv8AfVkw9NBlDWbZJJloCvpIcIaJSedWTV/croQ+ZL00nWXsWTfFefNy8tDhk+/WONQ3BJISvM9NTMikHXlpwQxs3Ly5emvK/wBp99oRZ/BbuWeEofNv0wujcg7W0kzRE7nyxrtm/wC35WPcPu+umI8QO+Wt9rbkKSSP6Y/qL82fjw8Y188Zm+64YmuoBDlHGzadJq3GTLH8xPxpq7Ozdc9bm+8LeRdd828u4Ygur4b54/cEI4ITVkJqJPirZ7yduCAJG3tY/wAVV4VZj59wcZBRiyoxj0iEQZQu7k/bsZyDIIkZCR5RSKyk5KlPIVms47kIddZxlbiy4+qIZCLSAsIGbUYyEibiyyDQ9yudDxy3GegraLLIQY4xFzEruV+9wl5FiOSJwQcmrKsMfehjDMVwxoYlFETLIMazeKjDMLLlGMWWMZFsHhnxoxjrEN46IMkhMqJY/GH9GuhyHE5IUmYONaUScL83pD7Nm5MbbfnDQknMXRvHJ0hRpx4usVYjxVvQJhjD9DmMuofpLhe4HFVywTfmbtq6EMYnEhB90fbX0s3b4bwxvCsNvutAxtiOm4yDJlyyE6a43rUtNNj0DoFe/hreA794M7lbbCQg6yObpHJH3ctZvd74V8T368tyEalbD5gY8zqr6qB3e20PMDIMRCR5ckcuYPpyLJ2ew2PDdmcXKuIcRCRxt5Vz/wDVqe26j+mz/cPu9w2fd7u+ZsTjfOYhj0yLzH48N5wLbZvdtqupBEKSRxmZup011zfB4rsP4VjrI+bEcRxxkcaS8D+ITepXva3hPHw65W/TJ3Vnp2DTnTZQrNydfDXNME7/AJ9hXEfvKsjkvw8epqr0BhX7Q4m21jI6rLzAhx5i8z7sd0ty3munA2I5RtdQhB6S1jPwo4quWgMcfTkVtSWPz/SiulTIaTfl4urrvCL8Cdyxb9QkmaVezPBbvauWNt32HwRjI3K3jIchM10QY8xeJ7D4IcY3h0Ot8AgmYiR+qX5a98eHXcn/ALpcB2c5z8s3E3HH2o+4q3qNIcIa5rLC+o50/V0y5YItt4fjISsQnEcjcgyZoiLk/iK3D2re1ZhgxwxINu1cEIzvTBuPmhfM7g11QF+Ys3UhHb4rPmMuMeqnDO/V35+QhBjHbyk+HGQcRRRqklk5E6bJ81tXFhSfZR8w98HgVxHgN04uOH3wsW2soyEGdgOQoh9sg+muH3I1YRDorHI4ESP5XzF9iMSYOs1ydPKGoysbhHqAyy6nc1CLz/v+8E7HGzUhIGLm6FHKQgG/LFETuZeWRdjg/E/8dXG9S+F/l5JPn+GD38OSQcoxiRgXj7n3A64yjE4GQnqxrQb4N277djiJnaiD2OSCHG3IRvEUuZ21l/YAOIuAdZREkHHJ0pO4uylWdJ7JvPMmVJ010WW3kZeA8oiFcanSEiAmPcnRK5xFiIQkfdQ9neOmb9xRWMRZSEkGTqqWcNBxOKKxxxDJmD7nbUnahUmcG4z+7+AAyNxSEcd0pI0vDykrMZBlE3FIQhCdxD2gw9lnnGcpHAm8ZJCZZflphM+Da3FYyCcxNxjgGPSW5KG2tHhW4yHc9QgydJEPAsXgmdHPFK4jlk6QiKvnHwbWQZ2IuXEMY4+qJVmuULVxIxjbibjGMg1tsCPTe8n7MZHeZmE+UrAgoM/ZzuiyZhCZmkg7w8B8RWRiUbeOKQerIoe5MTMJCMSiGVuMQyERsoYINygXTMdb4pHEZCZfSIqzCBKOghykeCb5ZOlIhzPKGbVxxtSDbxjEMkeb8xWPLxRyEFbEjYZRjHIRGwIaAMg5yFeCb5ZOkrDBGZqSA5CPBDGP6nUVdyMxeMIyAizBjGTqlGoYzF414AfAkESOQmWUvqLVtrEGs7oLocZ5HBSDGQfaRE7ozrgraCck5ghBx+ml9ttpDF4wHKMZSEIQknbRAQvmbUdFBx8uWTM6qGqz3kSVuR8xkuAhkJl9VB84AToc4OmMZIx6SYAePg/CDoEWIYxydrMU9/HMXm+R7Y3mX+INBYcIQGdfCH+IFJGQnSGrAhabROCc0Xkyj1CdyNDs3jHlfO0cib9MnVKiHhmvNDISiVvHHH/MW2wTmreBOEThqR2MTcUYxk7qrNcqzXRwStrK8E3jVd4trUInlD538PzAxtxqsDx3z9wGOMpBDHmD7aSdOaPDEC6GQeXljy0jeGmLIMelqeqpfjVhc8ZP2hLzPIS+SsoxrTYtpS8Z4zjMWckhW+XIMfcTQxhvHThqSuJuWMjgg81JwvCW0QxjzOaHGMZE8th6Lba3AH1YxDKMkZBjzZI0TRqSGTQ29wOsZSEyyW9DitvOfCDHE4jkcEITVVlh2c4Juc5HI3hctuPpCH6iIZx3Jq3oBEMjX9sITqrdAVmdk5XmhxSFHG3HHpRqvkxsmDcEkY5OZIT1ER8CFqS6yREYEGNuOPKQZ9tFyf8AI1u5G5SfEEGtKBLaHk7M4ff2gpI8zpJW8eTC4KKxlcFJl+qmF+uVHNDHQSMYhx/NSMIYBEd1jKTMJy6xsSpzGbRnF5dpP6lEyZ4UBeGg3R6Iynp2V1Uyf1bdqiWlP2dG2ZX8xLzcEupJF1FYbJEShDnD6aqdbrdisx/ieCP6irMeEuXqKwxs35qDMb004bFZjVm2cZNRDwz+dWFMPqKsJ80kaGEg/wDFDvDUMmskkWXINVmNDJXXQX/NXlP7Vfx7Wrwibkbg1G+H+ll+bkbWsY+53FtOaNk11zfN/wC3O+0OJvax5cN3NmfFLb8OOPjCD0nRO39NfNcxiGLICj4gshCDIROMYYqdbwsZPLq6fSuCyEcSdUiTmCQwiO6MtxISSTpaas5ScvnV2HFtuUOHHBBjE2iIMeX1SJe8eEDayMSHKQhSSSD6SYGMPkG48orcRCFJ6qV215WFrzYyCK3ETMH3VJ1qxZcjQtSABWQvvQf4SsZ22izuhkrPlizPOTqIdmEfNSEI5bEdSEzNKMfTGoG5PgtebOxGQcY45OkNL1AwO8IdqOtpLGLqE6SxeKra1CJwSiiRwVxloj3wS5OXEdcTcpPuDQ9yZ0Wd+M9BMsQ/uE7ixROxp60we892tXjQmU46hO0uybmfFE+3V4obntxyjHH8QMmYIv8Alri+CZOacV15soySDTRmYhmBOMYuXK3IOOTSUGsp08dFnLJvOmyb6EYJ8VuCseNRgncjxQUnw7QmaKQhOmREb/sVYqabuXB2JLZzAhkG3aDGSUq8t/Z74bfYk33Wusdulb2EZHLgnaJHGMn5i+hjzCpL9a+ePWIbh0PMrJmrzzq05wyPG9M6Rk0vj+R8j97V+v8Aiq5jdYgY8iTTHGOJD7t9zNx3kXluAFBBN+4QekvpQ88N+HMSc4+fDE5biJGMhB5ScYD3A2qwuhvhtLaNvy8kZMqL1Ez+rTnPxmf0rnzpso534S/CiDBODRkfDIIZSSEJmSlXdHm71iFrGC1EYtykkISTNKNaB5bR35g3OR8Ni3auBkjH0vTGND7blQba4rOPmWYnBBjzJSiVBXJpSmxZyxp8OBHbbDybAbqAbkchMgmX+GjLDbAXK8uHz4DmMrcfLgHpCGPt+p6iItpmlydRscpu1HlkP8ztozElyAZ03G1dCKMreMhB/wANLpVI9JqxBa+9Bu6yFK3zIzkJmiJ01WYF1tvJjPWLmCkkHJmZnTGq7PGFq3G+JGMWWMZCdNZPGG8dphV+3YsSFuTh04INvJmZix6T7+Y9GgNfmoWvPV8sJwVwQeWl9yvww2ElZBxD6hBkXH8SbyH2CSz39qO2kdEJy5CdvuRrle8LxmMTFbjAcj4giEyxjiEX5issbpt7+2rc3OnPvnQH49gtGdrt/BcilvD9wQgyEHpDGPTkXku+mIbYAjWiSVxHITV7i0m9Te1ct7V+cXW4uylILKGPtDWTNwFYeSQQxOBxk+YPpr0jpONohro8m6tSd6d80CcYb9ISUg5On3EQAJAleDGSUZRx5ZEPcTVhatyUViK4K3jGRVzE2X6OMoxlj01ZKzUIZvCGw44oIONuIYxjINGZBrWStqQrZxlj+aldtMQLV5RIMkWWQZEYe5TWFvxjkGWMmWnbBSZgEMzUlbR8PNJGQhP4iMNIFhluxORlcfEZiXmNRtas6zgIL4jTH1VWYLQzW30DlZfEfEDItUfWMeBdBEQcgijdONMaIuQX3KjGSIjcrjL9JL3gQStyNHZBtykJzBO0rDM4eTgfFE3KSQhExqjw74IhjPQMkrgZG/aFGiDGfG5ecYnMriQaHZhP70bjGcZW4m5CyERAQECJvwOhkb8vIMi21gRM6M/b0OxjKQUhRxqsJucdN6HzT4gQyEy+r6asCE8pB0OxjGJvJIrNgXwXRKKIykE3HmemROa1BmKx2lb1koIIYm5JBocJgREGQhOXj05EQF47M6eAIxGV5ljkjylWF20CZwStiUrjmByDH0hqO1GGs9ZmpBjdCG3kGNv6qgeeDnjrGMYpCEH3UvCa3GKMlZHMhXEkg+krLbwGk+OJzgm5MwmkXMWagYYzvlRjIOSUg4xj6SDeXL4puSsfxAh/EDHpFGrAhgtclD6QhSDkITpKu5BdmdNwD/ZxNyZndHqLDM5qzciEtwIcZCSkGQYydJDhDRz7wYHcbMo9TqqPDHDebhQNpI4KMcnpDQ4XjUz9wQ9Efw+mkUTpE7x5lDGSIsXUS/RLx1kGrL9wZcGnGg/bM7zBpS6lPxtBYeoQgxlGXqEJpJxbQ+/nTcdZCDGIkbfL1UjZno9vIyZZYySeotIE1bNhHJ/SAiSNxjH002auyTA07wRGjWghbgImZ2hDVhraM1hcEoGJsNhmOCSapFWzCP3W4d0UEEQRB8wSTVUuTyu5OyPhjEO3iHmDW6rWPLkT4h1l5o441XcgjsNhbnGQkl0HI4k6SlhDQ8E3upKIonEcCR4qeE5Ah8wjgRCRj7Q5Euh0599AbwtAeX45C+pIjA8DMpBkJlxxx+opbbbReGxKxjKQYh5kfSTjbZx3KwkPXQLmBRjbjJ1UtJpTWBrws+FXtpkF+r01Ez2XkzfZHXWTjo8u1RGtG2v2RmPlRqs3+AlahuCLLIhzcco+PTVe7pWYMJdRB3IwxC4yKw/HLt0lWYNZv4hFtqAMxpVDBGDM1SKGMMPkj+oh3puTa8cko1nUXSmtl9+W9q1boMB3TEF4fDZW+1t5HBJOn1F+afx7eK66+KjfniC/vqylbleEHawEISIQ+nGvcn2+X2ilt3nX5nuywddeZt7UZPejtoTqdv6a+VZjVldDJpE02/H1VYyk5/Nze9XDNIOjLcC7fVVjw5HgiRjEMmo47QhqwNtIZqSusZSOBdzqofZGYRI4hjL+0EkUhS7Bhrl8B8IARJctLzHoC/yzibRN5CD9RGPAgMVuOiuIgsyMaHs7wZ3Tg75jI3dOJHBCLXY1R4YhnTe2vqykH+0kIPNLHHpqs39JCjBW5E4LlxkJ00OF5WYTgg3wxDKSNvH25EH7y5x+Q9YyuSNcseZqo2ttRocNFtE3ooAIpOnQPSEleKnlBnXG6GIbgSXheDM6cRkK2zMsY0nuRiGkJWPML6iVsWONj0OMN7PeT9wQlcXw5IyJhbQgMKSMjlxHHJ3UPhtnWYRKKCDJEMkg11jwQ7n/APe1vBbyH5a32YnOkHHKUsai5OTrnsTpS2ZGt7E8De43/c/ugbnfDE2eXkYyPDyElKMmn013S5GHtdDaUSvYh6Yx6pI9RDheNTmZ0DGSPLkIQY4henGiHmGyXF08o95CYtxOBkbkAMY+n015Nm5FKZHOlHrWDjcJ4/CcxFnZtQtWZHwI7eXMjIOIUnqJeztrHFT8hyVths2pCDGMhCZvU000FYR2104toKyFZ5ZCEO4kEUiDNcnVydPIwMhtxSFIePNLH01FTtfqHMzreOuUoocibi+JcDGMcQszqZkgyIxlbSPLXGxPzI5CEJJlF/LUv2Kri8yAAIKJuSSiPVH6areW2t5y7UBHLZwIY5CDJH00uTGxA34ZnUlnayjauOWcHIPKkjzPmIe2yWG38rRGS4OnGYQbeIQh+mmAXleD2BGrR8UTjUbj5eWXufLRDO2nsBXD65VickdEGNuMfy9RMMBhw3NiON2f4cRI28g5YhqsOD2Ibz9yN4LMkGOKUfzEwNbRmdDOeiJuIkcbcmaiA219tvPKUMRCGJvJIQnTkQXNyPf9uBt28jCVwsD4YxOCjktd2I4ITM6YyZi+be8jAeI90uKHlgxOxc224CGSMZNIvqD9NfXy/WElyK4aPqBuZcuMfb7i4X4r9z9jxVulcW7E5JXDWT3W/GOVyInbITtq86J1KkKa6KDrfSfqp7JvmHbQjZtZCVk5j/HXmC/LRnOTYbHHRKMTgf8ADW4e7gR221wPrlE4jkIMDfNjk1Env2AyWFr8DKIgpCSE/tUeWu+l1bH5uFr8N5HDhsY+5GoecnxyiGXtjRDyQLpuccUZR9TpKwxiPBN6ICySEJp6SIuTP2WbjOCUgiEjr01O2zUlJU4f2B8sLq4D0iRkLJ3VXyZA4ckoPmSD8hFYY81+JGQRG5RkyydJBgMMzBxllEQRMsg+qmSqVSVDg3NRW/gJzMpJOp/lqXJ4f3xb6HQBlJGQg/VzEvM8AZg3rBWUWZGSQmkiNvGa4MwAribibkjITpDTC9RgYzU15bkrakEQQ5CDH1SKGMxM/k4CxxkyPUUNeD21+QFBBElbjzPTUDeHRroTgALmI8wizOiNrVzMTOiEHJy4m8kAx9TtqwIWO0rglBCcuUYxjoH0lAvDnv1w2gaiK4E3H5+kJS2vHZnVwIBiIhCuByEImzqcICztrPmCEfF5f+zjGiDW0YWrwhLrG3EQY28eqVD203x7isjGUhXEZPSUtvKs3TgfK89K4GKOPKEj58ENZ8dtkGN0ITfmI/VKh7bzxpCAGMY5MwhOqgwiaSyDIQspCEy+krLbByvndF5gsmX0hJJ2xZbTEC1JXyo+XkJIQnV6ajPkQ2EkjEo28ccnqKtmA5rNIN98QJuQkY9L5asCZ8FgTziLEMY4+0NZqNaPQ24LBvqiGImn3Rqu8Bolb/FRsyj7nT7aIuVyd8o3rO0EQhSRjH2hpfcjNdl0b1nozBNySD9RYMnOix37yeYjcUSRkdN5JPTVbyQN0bkJE5ccvGONDvAjeX4dfGQTcrf4gfVF6agQkM/ZjYkkHmanSS0mUyO8BmdErJEP00nMacsY+2mF+yBEHx6RNRK2eS6ISsgvlpa6l7bWYVMMNrJWSspXBdMcaeMrb7BOLi7IUZBEHJmR/hrN4VDMIZz5Q2pMutaBmb3kVxzQCEt+oOjuoVWacGMS5FcPqGn9H5eXJFLGoGO5NR3muNi3aky25OqqzGY2f3eSiTqZEksSRvDEvHMDroK2bySR90iZSiDOZpcrl74K4JXKJvJI3jy1n/eR7wXlNNxzEjcfpqy/Xg7zl6AEyxZasDhw7zaTgHHcIx5kmUJLTpTnPhs5iLaF2ydEI1GQTcRPiBkItJc+ReNXD4hCxyfDjk0kHYDUGE3tRxj5gUhJO6pATnxjGAQ7fzGYSTtpitrTvUOL+N6esvsLs4tu3/8ApRfxdmxS3I1TaKDbXt4Mz/uUQ1fsqQ5jQF4O6pNMJDw1hzK9NVup6ArOYYSk40OYxDCkHpqx4bKHJRl9NDmN/jlWvoFezOk9VeR/tbvG9X4M/D64dWoYiYgv3wTMZCaUg8wi9UXK5DtrUh+mJvITur87/wBsN4xn3ii8S1wBQMvuPDjgjJuMbjKkkzCKXKfkVubXsm8n4rxU6v10cO3x5XF0cEJxj6XcS8IphcEmXptyKs2S6cEHRI3EQgx+l/oaID8GUdHBGMQ5RjIprl607xBgwtZKNQQ4iEITppXcjDC6Jlj5cvT9REG43hY6xjKMo8zM0vpod5Hz8cfw4pCDQSIuUgWrgnGIROXyyJfCRnhxw7oJtcxDjIMiIuQT+5iVkHKQsY/lIO/B/oFvx0RPOY0yaRfUWdjac1ZoLbZm46GJeXEOQhCJPBQztchDyEKQhIxphfowtXHxxSkjGMnaKk9+NWHY3BwCFl5g0uixlIvmrC1HHGSXMIqzM80hNLL/AH1WY8BSV5asmoeFkIlLKU+w8wSGs15HRXKLmup3Rr6AfZ47qx4CwG4fcjI4uhMwhNUo18/8EhruV+bjIQgxyDGMi+unhpweDCu7S1sSEIKJuOMhBrm+v11z1rvoEu/I2N4zs9Zro3JWBiMZRyDITMijS+/WF2zdDgOLlxNxjb5ckXcVewxHlrcDO7csuV1IG5Ii/UWP3kYwtVtauPeWJhMm5RjG3HJmlXC6qUeh7Jz/AE7zw1yHbPihuivnBcsg+78taD9Fa7laxjfVlZNy/Ex/M6ax+7e2sQ4ct9bGvmSP2cgxkzClW4uRzmat2pIxN8sbiPNiH2x+oo1ZJPoDMZi8dN6GhCSMCDJIMmVH6hFMKvB3hrPAR845jXkytRBvLOM2IyMbNGVuKMTiQmUKT1EwePB2H3exAcRSFcEHIMZIhfLIsF0V20z6wtCEfAFI/cEHGMeaUasCH3k/+KIQgxacmUL5ih4AuhuqOZckk0yONImnIp7toeC96u6xDcOm+YwGTqIZmlyM1uV+bwSRiJJl6UiHuZjmYDP71IVwWOQY9KORQBiGaEottbZiMQ8yQcQij+ol8w2bXgG+bCeFzMtvKIo5NP5iBQYzvzu23TQKRwIZJPlkJlri/jAxUO27vnEhCNnj9xqD7a7IawvrPZsisRR9QZCRlLmLxv4wMeEv28ZvaiEjIwGQmXpZny03G/MTc3Dchma5cQiCzJO6pfoDWFxWTlpBDyyIdmGsLUfBRllHHGobj5AlZBlEMQ48wfUVvKnkTKy9PWev1YfBIWLx2R2QcTgRMztSJhE0M6eVkrG5GWQkceUJL8KmGzK8jyyOiE5ifSRgTAeNSAIOJuIeZmK7nW//AGcvXBx+BHcsE2q8P+bH8MTuD0tT/qDWfNuxurNqQ7SsT0fbGth+iozMHBKCEjF1B6X+tNQwXwWuXmj7gxqRLOpNCp0CdPI5e8sTsDDztSjiJIOMekpcjfs9dcosskg11Rnfh82OjMIQWoMhP5aMMFrcg/FtBFy/hyEbxKyl1b/Yqa/C/wDrcjCEBroOis5RN49PqoyEhnbgfNxNxR5i6YbBNgeOhnOxiJl5cmUk5tz9q58hxuyCIWSQH8xN/q01RX4Xv/Yx4THNebgOSJuIgxkJ3UZbbk6icUEIJsSQghydUki0AdydHNOKK3zZyQseXmZUn/tocO5+sJSEI6YllkIMkkcSmy6ljq6nQMjh/YV2Ar54Lj4xiJzBCRk6qMsL18ZpPRQIcTghMzqogO6V8EOedtzEkYycx1FWbdvfGbWSshCuIycuMZBrP12OVTomR/rL7bcjs7MOuhqPlxDJzA+6oYwPcRCciUbfl9RWXKwXW22sZ3YySFHG3HHlF7iruVyfBax1nFGIYxjGTKUiWTj81bXByOH9iswWIbCQdAyjIJvHJ3VLmFjta8AKyicSDGQhOqNWXJ465UYOAb0ZXAxjGOOJV3gxJW9D5rIQrjLj9PppnzRqSpwS8M4WrOhi+kblcZZCdJDvDH98t4xiISMg5FLk8YvHTeg9BWMUhCUd1B3hmP3mz4H20VvKMhPVENL1menz9tXcnoz35nWcGYVvGQY+qo9eDM/bnJQRl01DHOG/W8Y43wyx8uRMMSM4XTet9G5GImXGiiTrY/FRqDFHWPKlIRJ2Zv1x5ScY3NMXjjiHJl+ks2zMlruXsNYzMPlRgroKQZe33E8NePc7pxQOIgyt44+0kdtLQFh5ySNyjy0ZbeAJRnrITmP7OOPKQg0+80CGgIm7p2TliC0xkUuW13cmsdEYhlJmeqh2bwBoyVtSPnGo4IrLlciG5eMhBemhGnMweW0HKtyO4yDFljGPqqsJyW1g4kHIN10x6okvttudmKM9ZxiizI+6tZbQk9wtyNIhXAriNwMnSQj1p2B7lbAPGg+RrGOIYySEVlnNRcit7UeKQUmYPqpWc1Fn5iCsrkbonxAxj0k0uTMbwrcdqiHE3kITqiTGhc3fkEHZS2CWDZ7eD/l7VE8smI2LW0txmJwFoo2bKqY/6tqiEd+wU3AEqHePCS+moY2mhzGr9sahvQFZzZuYQqHMYgRfNVZjQyedD3J5QHb98Y8uRYnIbHlf7WLxjUeFfw03Stq+5a8XluRs3JH/AA1+c+/YqPeHVwuRHZHNwK4IRx6pCL6Kf7QV4xh74N6DPBVqrEW34cIQZCD6pCai+bdyFMFvRXEIkchI1OlNy+TXZRWHJ5egeXEPMGT8xGGMQLXU0tNJwvKwunHGOXMkRgjk9o5M0aZtQaSWBCP4eOgchc1x6SHCGYpBkoEJuLTIPqogIRvGox1yDlzCfLUeW2YumUbdgT4fM1VhqmKTEC1GQhCNhlIOQfpoPFUjNrZ6CDy/7OSPNKP1EZio39FW8hGpSykk1FXiR57yv1vrnIMgm8RBk6SGsifEhq/c0DpqITcrjUHq9NI7xnOiUZsYtPupheDDDHGcpSFISQZEnuRqwuiVyZiXRbY32FZjfC5emoA0zXyZY1WYNcqsFkikJWlrOTabk7kAO8uz1voyNxOB5ZF9XLbvOtTOwjIxdtijE3HGMjiP6ci+PeFbkMN+bkITL/mLrn+9R8GwuAVvnPL9OhUvVuk/V9ibhdRniU8j2J4ivGlQzakY0NREeNcwYxkkF8xeT8SY1JiS/DPOUTwuZmdUeYsua8DuTVuSfluo4JJmlUDcgXK/MwHricCGMZCD6q3n0mcJoWT1e+Vkdk31Y8Ottah3fYfYkILmPdY+plZi2AQviuiWpoRsW3iHFH1SkJ1Fh90oQBwlb6yZYxMxjyyRl01sBGdXi6N+ABWIyjIUhO6Ma83zv+o5vTMGnrr4F5o7bdBsQWoZXAm4xjJJlC7nzER+lVDNq3oA0GW4SRyEH01HhqA7LhRIIlwdEGSQY9IajwNAcLjgOQrgWYMhNVRk7X6h7OZqFg3OSgRXBSEJ6ohyancTR5YWPKuHwIhjLGNuORWBtty5ohyDlcCbjjATLF+J8wiHCGi/RxjEOIhBxkHlR9NDdAs62ZW4Hwyviagx/wAMajy/EDa3Fb6gQ3jAkbcA+kpcuRtvu8bQjklwkzHHSEg7xbYXQ3UkrcWa4k6qYAdy2DuQueO0EJuKSQZ3Gr+WvF/iuZvg72iEI0bNreWPl49Uo+4vaFtZtb9dGYI425SEJl9Ii8f+OpmC27y2Z2hCkblHGPqikk/LTcf82kqeRyuGsxCDoIIcSHvLygzUYyEy5MuRDze1rmE9NWGNQYUgx9OORTpyp7ibWnfNz+5BO05wADj5iSSRZNm8utyL98Q4sr5q3mNrPWFqN1XWKN0Qg8vVWPBbaAiJwHLzApCDJ3V3XScadMd5d8R51IX1zSw4wfMxOCUDlILNkHlF1FpA71KNom/NjzBdwf8AMSPk+TwlnxjIUgxjIPtoc1tHyw+UjKMpJBjJqi9RSadNmqcb4kyJ/o2DPFbG5ZhIiJwyExuXLjISOIkkY8oWoudmtrExRkjKIgh/EDGqzWyErigdxKMcgxtxkJ1CKFXov+tdx+LJ/wAjqHudoYXkO5zR9zKUDhWfaQg3xRjFlyE+Wubh96hdEBzwoxEjGmFtxtcra1cUHicuBEIORQqdJosp/EmPzbhnYXzNqSN0IpCjHH8ySNVntz4LvyEGJvzEfzR9RYu2727q8dDGNjJp/iJhbd5x3jpuMluLHmKL9DkJk+t4nNuLDbTmESt2cvL5eWMaruQT210Qg6CDblIQeW47f8tZMO+BqAUfAUTcRB5hOrH1ER/vgYmjISXNk6eVqaaX9NkcEn+pYfP+84/SonK8FY3JSZZJCaShr80eOic0MRRydQaDZ7yGJnWoSPLHpqz9JLVcnWfFmpc/qJlbcOgh5hux3hrGQAh5YySAJFF6iz9+3YnM6b+7bqQsUkYyDzZFrGbO3XKQYCFkLHIQZO2SP8xQzM+FLeMhPiXEeX6Q1JnnUn+6PTouHSf6cHH8SGfW3Ebeh8CR4IcYydIqX3i40bX7cdbEgnAo8vurrGJLaxxU1JQ7yiCjjJplEuX362vrZfm/HpiHG3OQfTV/g9S4c/ccT1boFIc9kwbw4w3S3wE2thxyE4+ll9NTnAAdNyNCEITmOoq7kbnLyz5scpBN4xx9WNWXI3sK3JWCP4jUH21Z7ZqXWT4qySuMwhSSLPhN8Vl6a0mKj0cq48kXbWbCH9cnUkWFrL2zy2hmKMZCFG3EmhgzOo4ykl0/lpWz0oyaaeM3hLa1j5rVyx90SEepgCcLVwMABMhiHHmdVRmY+wo8jMKOMcirMB3K4GA/MtxaZO6RBzXUxYB1/EC0xkQjazAxiW0pJ+WKQsYxxj0iLQQ1mKQY63zm4CjjIPSKk+Fba72icDIQRCC/aCE6ScTVhENiB9mP3A+XJ2kxW0S2hIG1jA0HHcCuCcwOPNS+b3O6eAk573oQY49OIicPJAPyO2tZecFlkJJlFSd4cFytbcFEZHBZCOOnET5iC5DbhY2dvekDWDzD2+zbmKJMa+PgFqog4+Hbt8396iNab9M/ZBCMPT9qreGh2SRogxspLzH9giUaihuxDmjOUnnGuD+OvxFMfDT4fcQYnfVkIQTcg24+qUhMsca7oc0P8xfIf/aHPFQ1uV5seBLVdRkbtW5HN0GPpPOmP8PMW8p+RW5tdc+b5Z72sSfp5jt4+rI5I4dEJJmS/iLFmMczpwSusRRiHGP5acTOg2twecRJf2gYx9RJzM4bW4GMZWzgo/y1Nc5OocJpijoIMoupIjLkb4qMY4xxqsMbN+449QQxxk7qhgTCccA5cvLJ3UtJWTDlcZfxBRx6ijM0N0gHLG16hEOEowOh8dcpOpGNWWcIwib0El1JCLM6I1J/YsxsWZq3zxicCJ3NJK7wb+lGfGMpMvLIPqoi/HmakrGOT4gn1SRpXNC6t/HWURCjzJFuJTS/BrM1bkdgENuVxlx6qDvIR824y9Lpoi8GAYTflKyj+IjJJ/EQ9yDRtf8AGOUo5I5O6lpkfcZ94aYuWOKIaHCb4Xzoy5BoDmDJmRpeY2Ulugn7QgIYSjrGTtroFtM6CwbkHEUYswi5uE2dJmiiGuiW0w7bZnB/2kcYxx9ISZOmtU9RWGMxuTrTK5I/JpgW0wTu2HYboM91fEbOBRkIDkyELGq9z7MFy5h3yghDtYxjb5cuYTqLsFttoLO1HXWOV5qEITMKuT6t1anDxzdj8N9AnSeyj0BuZ8V1qvDVvQMjYRBE+IISQuX8tdssG8I52Diti+bOfh5JMuKMn8NeA7zZ7UZ+3OQZRuNOQGWVNMK7zrzhV0Nr78fMW7qPMGTVj6ZFyVZTp5Hdyxtfjm9+WcLFm2cSHEIkY+YGQkhS/LRAbaRm1G+nIJuIkYwEHILMWL3Y42w/vCwuMlF1+Iy5BnjlKT5a3EPwjcFZBFzI28hMoRFW0kXSlFbwz55eSc06fNmZXAyDAMchSxj/AMxVvbkxuTknPHFaBsG8bdpJF9RK8YXh3YWBKwcyS4SDbtyDjKXUXJ953iLsG7d+4oxjWJ88KTmfdLBxIWSOSMhFJli0pz8aLTOnP3HULbvIaHNcLHamNyvbgTjMI3HIIsnT9NPLluxvJmrc57UK0y6nNvBizF4b3nfaQXU1mcMcI2ptg23uiSOBsB5pfmE6i43iTxI4txU1IM+KrkRvmFk5jqdtXeN8L05+SjnM34khwprm+gGKsVYctpXBLrvKslpJIQZGg28hRR5eXH3FxPxOXLA+Pd0BKLBjQVyulrJzowEbkGUo14/NeH3NOJBifOGreSTmCZv/AFEP7+oMwcUcBROBN4yD/mSK7l8L8FJT4w5zv+DWWHEgLkUfGTL1CZiM98e8i8oxk5gpPpf6jXNwmrsIpGNYityjzBkcETS242fBEQDRiJi81CH5gkpR9vUUanQL8KOjn8UY/PH2DN5F+Aa/kYtRxDYN4x+qsvbblDYSEO1ibib/AA5OrIRQ3Aa/OBjIUUo9RVu52eE7gM9A3uWOT0l1mDLhOGt5p1LN312CNklytY2rEgij5gY4ydIncVlyDNdB180Ni4FlkGh7bcmhnTf+zEKPLj/16aTmv1dyxbIQcuZHGpqLPGo0jN4+/ShxwVjFEP8AFVdteANdHBORlGV5IQhOkg7aZqG/cBCEESSQZO0RWWELvmR188LmCkJl931EI1PsWADajFJwDIWVwQkg+kNV27kQ65yEGVxlx9JEWG5OwMBnoGLl+YJIPqlIg7Q8HtE4gAUhBEzFprM9K0WWAIAlITmyCcFcEE3IP+ImHvIhmEnN/EFkyx6SX4bNQIrggGMsTgkhCdJWWHkTMHA+DlnAm5MwiZqmztoIZhPssJCErFIUeh6ahgn5CSsYnLcsZIx/2VK8HmY3Jq4ASsnOacg9IQ0wZmGETgbEhBOBDjIQmkVGqZVK5Bg8trtm6jOARScwOMg1PdtYSx1tRE+IJGQeXmKtmYBnRK6HxM1x8QMny1YzCx5UnAcoycxISQmalUlLm0nlV4Iz56wtW7sYylccxGMgySi+otBYcYHuTUdDuhyL1I8qQfTSO3PBs2rgbQ5BxOI8z+IqwvKzWYjEZxFGJwTL9QnUVbm9Nnz9tf8ATfiDIhTyNpcraR42I7BERx1O0VK3ltoxhaxjIMjYbocjc5G8pfU/LS/djeD20zi1HIQhNT9oyhf5icXI1bR+4OP4ZuUkg4x/ifLHqLl6bIU1vS8ak87H2OX3hn7tvzdqOsg4iEHGQmkh7kbk+XHJKQRNNajeQzYhdW90chSjkzCDjJKT1FnzBYhdD1B5hMvurqMGmybzjOwtGQT4kMQ3OSEGXLzPSWX2GJKOOVai5AHK8JQNZcOTqSqcZL2zSw7Cc1JWMcYidRaw94JbStxkaDEQsfLrN2EIzF4CRCl6iYGNDdMyuUYhxjIgqn38xgblDISgkRNT6iMCYews5CCc5chBpOGwjM6grJllzMvuJxhWwkZ35u1BGVw6yxkOPKQhVpM0CElytfB8MJxHIPMjlGiAvPfBRgaDbCHlxkJ3PmIczP3C6JpuYstuMZMqRWPGZLa/ZkOxI2t7ogyOPiJIiDGmKnWaBuVYXQ7bXGxeSSOCE0ijWfxJcqGd+cHaVjK3ddMY9JWXK5DeNeeA0IJwLLGSSVKzXIBrW3AOgWaOQkmZERLSZTf24cNRGqp/uUSqhxFRspkL+pRCy9J0fs6MaDYTLQ7w49uyQdGYiDBn1MoiXvNKSTSULav2P327yGO6rdzfL4+IMbezMyOSerGNfmn8Wm9p3v8At9OIMTvqByX54R7HJlC7Y/w19cPt5vEgTAe4JvhVo+K2eYocSEj6rceoNfFd5AYpCEoyy5jchCdRTceX8jlurZX36ycxuc5eSJsT+0DGg3gZr8MFY5W4uonBwjebZCEEWX9oIMfUSc1trCJwRjWUpCyDzFMV0qs+YMIiHkllcZaruTyEpIxxEKPM9JGGkC6b0VjicCHp+ok7w2nl5mZIkUWMvIrDcpto5MqXqJhbXlYXUdZMuMf8RZ+YgWox10EykQzuczrp9ONYSdZpfozdTL5hL7kas10ZkrBLLlj9JWGeTtXHTzOog7lch803IPpDj+ahH1jLzk2sc9YyD5iMcaDuQSc3mEilJp+mq7kAYbW3JGURJCanVUuWcbLGUo8vMJ1UJEpld41fJLH6iVhDqDTC8Bhkr4+ol+lJ7UtbT9tYHJzOPSXQMK82bC/AAAoykjIMi5/biwlW8CagLVuOshYyjjy0K7N/B0jdW8rDzDQkgiCcDc5fV6ZFsLbirnHUY6CjGWSSTpLkdu54L+BpW5kEONuTpaki3lhvFBhDrkzCkINwTukXHdbwqcOeybv/AIX6tPnj6moMyIYpI6I+3IozeDM14HQxFH1Bqv3kN61GOigshep0lAhIF0QhBlFEMgxxrn/SnDh7jupN5uB3nDwTjJvQ7aSDYDy5HEUvbIvXGze01xUwIe3RcwXUjzJSLwPcjcny76iQbgWp6o1vDeLomD93Lhq1Ay96FJ8OcfSGmyxdlPGpOpZPCE9lG838eJwe7Erdph99z2KCj/pB2TMEwGTpjGvJd+xJdcVXRxcTuhlcP3BCEOk9+vFeKnTg5yFG4K4GQgydVD5DPL4yiGIhJBk6S77pPSZwn86PHerdXyMqn6MfiR5dba/JQeUoxSRk6RUnNeDmEQeaUeoRbTEedYcg4yyt+p0lXu9tvtwbcCRiLzTgbbM/EVjr596LLJ7J7KcGPDjB8EQ88ubGNbCw42fPGDyiigeaMY5FZirCrGzlbnIxi+I+I/6aV3K5MbO/JQ0oiGWP5qzNmnpv4bJtJfjAMJxXQ1LIIYxkJ0hIMwZr8QdDqT4gfL+qqw4wHcn7cAKy8uUg5JMqVMLaGjmpIIpXBBuCR6Szr2IPOdJ+OgM20nxk44swmmg3gRmws4gITmCuBjzOqjIa/iD1nkGXLjGPpqu5RmbDoOMjaJwOP5a3+QnT+Ri3nNs3Yxjk9MiDDcjhfyDr+IklWwxhbfc9rZnorGVuVuSPuiWfwrYP0kdcAyRDkzCJa/lWejZQ0wffhvL+TmwDJKPU7RE8tttYhYRnl5jMzFMK4bHYXRByCI4E4yxk6qYWcJDMIKKBjIJwTmBkJqjTFLWk6U8ZXhwNDN0P4vqEy1YzCc0lAzjE3K41O6pho3xXBWxlb8xGQnVEpyYAunHAcpInGXH20FU+8OYzo1hukZBtonEkY+qs2G/ECJwMlcQyjzFrLCFiV0SglZSEK4/CGg7+zY22wvPOMmWTlxx+otKfulYNJ+2z+G7+ewv+MeoXUGTqjWks9+95MHlFYI24m+oPpZiX7sbDQ8dN3ZByjETTItoa2kDYSHGNsJvy5CEB6ZFj0nRvm5M/bLwvBu5CEYxt5Bx5aYGuVcUlbEYicxIMg0OzM7eWacYxORljIOPpKwzM+wRBgdiIQrgZCekmKqj+LkU4mDit01+HK4Hp/MQ1y2kieDI05ZuVwPMH0kRcgkDa3gxu+ZIVwMbgnSk9NV34xzbboTjGQkgyEGRaUoVs8iszwFhuHNNCFEQRB5hCaq6Aa8V3iwkPQMsZcyPUlHpkzCLm9+5541ISsYhtyjGQkfSXQMKvBmwa3ori5cTcmXJlen9Rct1aXZz2PUPhLJ756+bN4vto7lhwlGq4Fmjj6sZCLFvDHNHxjGSIg4xroBgjNYXBIyiIIZBkj0tPLXK5qzOo6CdTMTei1+wv4oxvPwosuRoSvCEHEPUy1lzcBi+RPLxksHA+OQciz/SV+pMf8BDM2bHpJwHaQ3TSdlwG2j49TTWkZ5JW5KK8sRByILqMttyI8NwDH8QIcnqppbbkQ7XgGSNxmEzP4aRzDC6bu5CklJHlpoEw2V0HBQUYy6gyfmIVlDALwl+akHyosr9nIPuDVYbkMzUbU5y/FDIUgx9Ikir2bfdt1IQ5OWb6o4+4g7lch2e8kICuXn2+XJ0kxH1KxXiswnDU5IhtRyDj6qX20wwlcD1Bx9RWXgJwl5sZBky/iBpPcnlZi5emlrHGl/gt8npKIKb2/wDeohZ6qP2sbf4XcSe8GhauCSD0/wDUieGCPaInH+pcP8e2+wnh78MmLMTjolcNWZOXH6hMtQZe4kZNdc3xD+1o8SFx3zeKC+MXxxDZ4ccckzAPMEIfUzPUIvL57bCwjyiDESQchJSxpxjC8ExJi24PnVcrgpJHA+7JmEkSMrMbOOugkQxZZIx9xW8puBya7KeQO8Z8m1cDayyFJKMcYxIN5wRDARpE4dD1OY0kYEx7aIg8ty4/EQdyN7tE4BRLzBczyKWxMneMyPHTjzjcuC5ZI9IROnJ+Gs/eLDWzE3HIMXTItJcgjN5BkjcF6gyaSX3IJGYm/GMRItSPpKBWazxqMuawkM6cV0EJGLqSJOEAwikJmD5iRawwYXTglBCDIUZNRJw234Bx55cwY41jWsZ1DmeDM1JXqDL01WaTlW5BxR/miRBmZAsG9EY83qIMwSBajkHpETGZ07zB48Gaw8FZJCCIQoxkVbzZ/jIQpBDHJ2lHm3nLXx1jkzCZg9VEXKQzXpjHHH81LHP3CO/Bm849ONJ5of308vx52reujpDWfN+16mklrGVBjM0LoZI10ANymE3nHK3jzPSH3FzcDyb7/wCzi01vMN3IgbW4ryij5eOPtJk0bqM/GaM+MLUhAPhCcCHJH0ij6f1E0ZvHdtfNznALlyj+IGPV+ZGkYQ0BsJJKOSJGPlz/AOYjGZoROHdDspHEcZB91LyZTpPWrsDNpiU2OqWfGPwox0V/DlHIMhG/+o00C8IaOPKizZFycNyutndEGOiRnJIQY8yJaRnfR3Jhxgym4v2iRcJm4PZR7F03rc7S/VsMVXKgLUYB0F5jT/EXP8YXesxbeBqOUbUkYyE0iozbjYAHRAMTlK4KPMdkJpems2EzUwm8ZCjbiIQjgZO4rzpPTef2U5uS+KOvz9Z65oHnrkVvINsUhXGuPSFlqPBVhaxkGMpIyEn+YRVnuQAtZAEKVvGQkHaVdyCMLVuOjmSjKQY5O0up1POKVY+8X8h3RB6UQ4449VDs78+toowUEj1Bx9xajeFZ2hrpb2IKBcwUchCeonBrYAPu8Y4ixNySdIRUrX6rGmbPhPWw9+ub65YdbnfOykcFcEIMZO2pgnCH6XyEO6ibyRx91azG1gG8aQAoERwJuOQY+kufmM6sL+DjIIgu31VjX5DZZM+fDXMZ7tAHFvKj+Gb8wMa3hnhAtZyOxEbikHGMmaWQca52zvxAXkbuuPmBZeZ3FHmJD3IRBjGMQy6g6FmdBTGpSjQGxsO2tXBGg44ssY+6mhTO7ja25/hijKQZCE7S5+ztpDuSAjkIUkcg0wDsPbHTdochBN5MwciNnqXTGn2azTeE8rNydHUjJlj+YrMKtP0bYN3XNCEMuYQfy+mk+Kjc4/bgozBiHGORPHgRmwbbyEB0yDkGtzKz8fCaXjeePmnBANBDIUg8ztIe24rHcnZCHIUbgpJB5mUJZNmGu5PyDjKQfUVmWzvJKIyxicDWmz1M+inrdABciBfuM8Yx6g/VS+242IzdEoGMQnEhCSd0irvFyaB5ggASE/hLHzVmLJ0yyIpUuWF3uuW0xDXRwQdAh6ZHA+qUmnl/iLn+Kjf084AMZRN+YJ5CDzRZi1AXgLY1IQhyC+HHGP1O4s2Hjv2MuOQRZXEhCEWKfeVKXDhTnzbzd7sY4VsxBjoKUhSDIQ/aQ9+etXlvcUDfRuCjjzNIuYq8VX79FZAZYszMj0ikWPs9tdYqdT10E5eTMJGm7f40aeFzpTY2ltCC2sCUVviiI1jkJHlF+WiDvGJoxtBl5cRIyer8xZO/Yw95NSW1pQMo9IeXmpXhtncnrqPMEMuZJGidGfp20uT2i5WvjIxIxIV5qR9NV4kuTE21xylBZIx8uQnVIoYL79G7g1OcZBySRk/lqYkMe5WIldFAhNytxkjH6aNaD49ge/x6dD4jlxGPL7q2GCTENhcc+Y4E4IMYyEHFp5eWsHiQ0LBuPlRDGUYyDItxN7hw434KxEiH1CaRCLm+t0/jd38JSps2BzPCPLC8JWTVcEIQkmaWQf5a5eEwzPyZcZBfmrolyeV23CI6yDKJw6IQi5uE1fxFZKB5WXIjpM+yax+I699Nau83KGzcAxiGQuoQaz4TdPpppftJvwdIaXhDXskJ2ldqWUvGsZyZcZIk0s4azZeYQgkGGPLy+omFtNybrqlGUiGKe2aMwkuTRwOusY4h5Y/lpgGM1h874kgswg+kVD2eNniOOMRRl6hFZbcl04HQMY2/bIhU1WGMxNZm7qvmRkakHGMmkUarvFyJcrMMZADHlyDy81WMrkQMjWuITco44+l6ZEjCaEUZ5CuBaaC5SVmMMLXjJWUhC6iXhyRKx4YYRE4NMqHhriHWRC2lN/Q/ubFF/Xs/4FEtJ2P2wPe33V8x/wDaCvEhXgndy3wWxP8A/j2Y4GPVKPtr6YX43wxJIxDFmSEX55/tqt/H++Dxh3igdcje1uOSbx9UY0rGnsQurVnwnreQzRxEGegoyRkkj/LVhjc42HXx5hRjjk7iDME5pByCIQpI/lKzzmKTjGWMuWOMmkQaspORoMMY9tEOuApXBcshO0lZj122QAySuCyEVgeAMjuRyIhcsgx9xVhNCw4JBvrhmanSH3JFuXIvMEdtdcAKCkcOtMg+klbwNbOSuuUjwpIyRkTgzMduYDHQMvMF1CSDykGZmOxR0D+NuBcvM0ktNnQjuRuTFmZhO32hpPcgktoh8dGYUcZI1pLlYSB++OV46y4x/wARK3lnJZ2rh07rGVwXLb90q0p+6dKkyt5HbRjHWcpVW9DWCMfHITT+arDW09saTnoiiJmE6SrCH3kUlZByy5YxrCbMOE00gx1xDVgTUcqMZBlI47iICZpyBCaWZlkjll9NL7O8GYXASsou3H0ktJ194eYZ2HAMfUSM4fiuAaceQLp4MhJR6gxjS8zOvaWSMXcy0GyVmNQaOMcS2GFY/czgYyfEFHHmLFm4IupJ21pMKvBmYEorkGOPMjTZl50/G2DxmczBuxJRzI35BiGTtRqTUPGreg4CMYiSSd0agQ1m93jA+iZlHISQeaIg00mPzQxjAN8QTchBkJ0hrFFBKfkbDBLNjZ8L80RpK4fk1CdUaYXK22C5SEBWRiR101N0tymwu4I+5YbcrgfLjdkIOWPtkWssOxjchOKxjYkGKMcYxyly/mLis3J8/N6703Cnzx+DkeMLO0wq65QEReaHJIMmUgwhIaQZGo5BZg/STjeEYAcWkGxobCyx8wSTKF9NZ+agNrcEIcpRutMmYus6bTx8HmnX59mRznNY8tpwsCVxjEQscY+6q7kasLpvwViIQQyFcD6UiIMzgdMwcBSDFmDJ9P8ALQ9zBReGBAHIOQTwgyEGPSGP/qKzq5+XueRn8H7T3e/PLrWTMESMcnqLQW22kvrog66JG+mMg+lGq7dYR2ewkooBmCyxkITVVgTDttrGeh0UYy5Yxx6ROotWK02U8Yi2mJcnRKyfBOCkjHwaUY1ZYbYxeFGSDmSFcanaQcxLExcUcbIoxEINuSPVkIq/eQ7BZpOMonAhk5iPqkQzKdNnjVg3bsbxdJyUCEQrghCD6UfcSe5WcFtwkQbFiIhH7wjZuQeqUaHtu8J9cuXBRLy4pCE+X1FrLbAzw438nLEYDITM7iE3ZedNlOZHgnDdFsYDnJHcOYiIMnbWbx4UZro3JmyCHH+Yt4z/AKMtbd0SMhI5JCE7iHDZ6Hgm5HzSQghkJ6Re2tNXjE83ybHP7bhR9fhT0DKQeZH8wastt+IEQ2J6yDHJ+EumBDBayDanGKUf3I4syNZu5YPBiR12yMG/xEeZmJetJn1Lvp5ODH2e5e5nTiijNGVB3J4QzkhOAo+aJlreG3V14bFIc7Z83dDGQceYUqIeYVBeGDgdDEpCNSRkGTVEOQax6Tolf1GDnYbwQwiD1ZYxqy5BGzEOighPUTz9AwREoAcvMSDzCKXLd7WzdEordijEMZCSE1UfJMlnT1pfsVAuVhb0DHE4E3GMn00HhYww3XPy8vqJobduTmnHG7Hy/LjIP1ZFW83evgv3A6BtixD1CES/IjTyMcrxJeCXJ0SciIs+KnVhE4AAmXpxpgz3b1mak46C6mpHpJxgndWxuV+b88cpB5khB6QiRpk5d7NM7H4cNZPulMA15cTkFzEfw8nVW0CZ0Zg4OAgxk6Y/5i53eLBXZ7w3IxkIMo8yugaIZ3O6ykooIQpOoOPpo2diLkznT2+baXEDFmJvQQ5SvCtyEJHpCJHlpG8jDa2/xcrgreP6fbRHvKgNhbx1iK4KMhHEmkIfbkSO5XIcrMEeWLqJdKznw8heDg7KdjWYVwqfEl04HRJOQGMkerEtRiS20XK/N2oyC5fLGQhBxqu24VfWFqMjVrJLmErI4jKKTUjzMxDmxUOwvyEIArZxmDbkIP09Rcdm033eq9Jwp4uOy+855QETegZBiHGQmWTSkJIsWGQLXU6icYwvFFzdDokHlDjkjSvkx5eYRdBgz7IOS6tk9+QV4kNtC6GRLwmhEQcmWVOLkDJ4OBZ+GIpBqw9EeVPGYBMTlUwtpqIvU6iTswkD00QHJdR6cqyxSbQBuVHK+SshRijRF4MPmm7vMj7aX201BhOKK4iSjk4CIgJucakoypBdNCurLyJeOARRuxyiGXU9JLw5PnHmkFqIja8GFrylZNXUS8xq5SD1YkJEp9iTzCk6ahs5r5Pb6irMagP4irCaYrjg00JMl1HBwbP61EL7P+BRDOx+vz7QLxOMfDT4fb5iB1IVxy5Bt/mRxj/iL81+87FRMbYyuF1rrkIVwQjiTVzF9jP9oi32V2fdphvBw6CkcXR5zJB+mNfEd5c6DbbgTjKL1CdVLxvsm5/Orsor2PKPgyEH6mX/ABEGyuU3L11kKOWQn1FWZ6MJRjoJL8OTUVbyQzXTl+HGOT1Caak7PVC1nAQkM15ohBFlyyDJ0lWYJAutARSCHIPMVZi1lK3GRoXKGMbiPSEoGA3MEroKNuLMGQnbT0akljMwwunByALzEZOYGPudtB20ww+chxFIXMkcaoidtQJphSc9mCHzJBk0i9tKwmI8kORiMgykzCemtNpkpGBjHeuxkfDLzD8kYyD6Q1Jmj0rh8MhCN2rcY24yD1SJOG5DNeXBxvuWbiHG3H2kHcr8M15bta5Ct2uZIPqo2zSfTGoMv1t/Z2JKCtosxwQhJRJHfg1xSDoHGXLbkGjLxfhnHwNaykI6yyDJ0kHeHYAsRj4CDiHGMnqJVKJsp07yuYYWsY6ycuIchBk7iVnNybrT+YjLkUltatyVjGMjrMjS8zsZhZmpIlrOcxBjfFacoyj/AAkvufAEvkr9NMGYRvLo3GQghjL1EO9s5wR8dEQykJGTuoSZB8wzpaTBNtrDzBK6xiJHljIkYQ0My8eWUgkRYbnNdG9dZCoYyZ983QJmhnTeQZCSjjJ6SYX4zELVxQB25jjHlk/DGNJw3Ihit+Ag81vGP+YnGFgkv2N4BtBilcZhCaQo8xYtTXPYqcWWzI1t5Z7b+jeFxsZCjyxyRt8paSws6MB2Zw7fEGUZRkI4kb5v4n+tNQzOZ+zHWMXLizJOYyi/TWP38X6iUjGg8oyjJJH+WP8AiLh5eer1WteGJ09jw8bwry5EGQhJMuQmUpCfZy4xxyFJITtIg3Aawt2hK5B8xlkQ7zbM/JXB+wD1CLvYy1z1vFcrJ2V50QJiGdOHQyFLlxxj7iI92kZ2FvRQMo5SRkH1Y0OYNYWrfzjESSSTuppmPL8MYyF5hqOMhCdVWHoifgV3IIw3BuCiQWoQZCE6irNtOa6Nx1upeVHIQaIZm2mdOHeU5GUmXJ0kHbT13LmHVdEpCkHIQfzMxJpRmcv9aYkMPmmdFYxjbtcxxGsvjDElF+K3aNJCt9PMQeKr8S534kAxCGXLjGtBhXDYwvxjOOWIcZCD6REv3FlOeiGwYa2gw3Zm4wahcshO6iDGd+5hteMXMFJlj7oxjQ8M15I1HmxDjzO4h4a7k0cQEIWLLGSgmktUWnk9w0uQaLla+AY8sX7RmaSDvxhshMxz/DlJl9LLVmFLaNnzGYIcWoQnVIkeJI7kVxWQ/wAOIkY1mlBKffTXM4xJfmLMRJItPLIPuIPAex8awuCTl5h+4jIMnVGNYOY5nRKByE7ZEZbcVPra1HRIWP8AhJc6Lf6KevXN0S73hozakGSQZNUZCdKPpofB2Nj3KzPOAghEK8GQg+qVYe74krvwW/cEtAYAMHsW9FcZXBW/MyD7ik7Ub6Hsnro3FheUGakooaDI4fvBySdUaD9wtAleOqAcz8RGOTt9tc7DjZ1zU8hBk6Y5NJbjCuKqLxZm463cVwE4HGPpFRsQqYVJ+RZcjNeacHGMnLlcDGP0lZCALpwCdyRuVxlxk/iKsxnYXTfjrEMZXBCQKyY5it+NpI3KQhCR6qSSMMWZ0MdFY+YFpj7qgrk6Z3Vvpcvy5MsfbQ7wwAOm9BwEbDEOSQfVIqwha5nHWQbgTfLJ3SIaTnNZYbk7AJnGAvLibyeqJD+8xmatyDAKTMkJGpbQ0My2+sDshXhW+YOTKQ9ntrrFXLsQDzCuBi+aSRLyaTnPYnYsudKa2g3QblH28+13QlDErax2tx8Y7H0sskYxr1Zg/wAFtqxVhduO4k/ocQ9MY4yl6kki1Hh78OnuezN7A1IL3fa4yXAndcE7i6pfra+wq15QYCuW4iSOCD6vb+mvL+rdWpzv4+b1npPSIcIfN87952FX3h2x2S1PsxuJwQjc8eqNZvEm8JjiSwkGQYiuBSdPqSL154zN2IN6m6u4Ht0ZXlrb8yMfV+WNfP8A92DC1jGSRwXMJ2hE7au+kT4X4bEHq2bTF56y8xqw7RkroyykRk2V9yPpjUNt+KzKMvTy1Y82jM6GSjTkkXWS8bk6U4UpsDmjMXTSe8W0cslGonhpIh0UDELMGg7wGvrjiiy5E0TozYZDCkTAJiGjJ1BIMOSUlHTRDM2cSivKGVLTPzNAhoK/bko00Q9ktrqOOSVBh2Q9QkasMbNkoJLEmfgh1V3I0LoZP7OVWXEAzNWZOCNwUZOYQ5XlHUHq/lKsxphSfhoMmhjZSrehGHMorJIqzaXnry1JoNNLSZP6GHybMwaigzeTYojYZrfar/aIt8FGK/FLa8PjOQvuG3jk9IhMzM/LXzDuUhmtwoGQZSZkgxr059oFjz/fB4oMaYgaEclGW6EHGQkmWMnc+mvOdxZzNXFZKBiblk09XMUiU/G4qlZ86bGbmhatx1g1W5B5aINH8OMdZY3UYyekq3jMdt93gjilJHHHmlUsITidcfAMoxEjj+WRBmxYYxOacHrfRuBdPpRoh4YjPCQ2NFYnLe6EHGQmXF6aHMGvkG46wSDK4IQfaUvwQe9G4yAIQYm8hBj7izMvYmKnhA2HPAIXNEjbkH6aT3J4O2tcjmRE5eMchNVGXI3OXS3joPG3j5kgyD0kvvwfePL0DrlGVx1MrLRRJlrJzXL3a148shPTSsNzIEv38wuYnFysHOPxjHF/lJebCtZXQx0EFGIaUupUmXmeV7XUnAXKRATEuQoKziE3LmZncTzDYCS3BplRlb6ZNIqz7wJLaWDKystCTPXRDHJcmsBKNIkg5Ol3EGENAfOQg1DXKsxCErrilQcxAyeeXqINnM05ygIpBy/TVby5EuXL0HOXlxSIcJpmox6SHMEgSjoJJpoY2KzasdCgTQRow1tGYo6wEkIXUH2kvMEgS5nSQb+bcYbeAeCt5CEyxE/mLpG6V4MOOHD4lZSuBD+HGMchfmRrkeD7kMO3gJRmao/Sj011jdKagN+uBAajoY4yEULqP/T82nTZf8zg6xbTVvbyR00IMjgTcknw8cUnzFyfEhiXjFtworIKQTjTJqiGPuf9NdACYfK3AjsZI8sZAEcSSkXL2chms9DWNuVxGP6hOp/rpqk6BjeRffGGR2Y+sQENDN+OOvmRikkGh3mc1IMdBSNyk7imeEpJIxOMsckmUVEGKPaKOcQ3ApJB9JdtseQ+RWFkfmhjrBliHl+l8xQPvLmnBCREJHJIqzXgDIZKxyEGWSQcasMYBpGs44xEGJv2hD1P4iNgVhCQNhJRQxLzBY231CdRZfEd3Pg8pLUAcTjl4yd2T01pDXOZ03o4y8xIQvpfLXP7wZ9eL84fV1lI4KSSQZNIiXsW2FPv5tBgnBNAGA3xCD5gRCSD6ooyJwEtbOzuHw5BOC/tA41z8N+dhLqFHKOT5q0GG3j65XQYyVkEMuYt507zM3G/v7zwJ/c9icPq6xEcFGSOshJNRD7vb8S5XmOgYuXat5CDHlSojFYSPGHI/DDcFjJGNYvnH2CX7wFYBiIVvHmZko1HpTyNMeU6cP1dAuXBhS1kJQSMhRyEGRc3eXOu/Ohj4PpjRF4Ldbw2nJLGIeXmavy0PYXnud0OuvMILuDzUUp3puNjT4cG4w3hUeFcOTnGMjwshHAydLtj/MWPv1zla8oOL9okJH3E4xTjwdyYEHXR8QWOQ5PTQeA7axuTonNkkcdPMiEVY5+gns4d9BH+6Wuw2Fu+fHiIVvzMZFnzGPfnUdGYMRB6fbWo3qYqJKRjQQRRiGMY0vsLweFbCQ9f7QUmn6aKTNlSlJ7KF+JLaO2mj0yLQbmTA/S0dbugpGf9oWbhJiS6EoooKUhSanaW0wTYQW104okjcCy/SL3FmZWbTshrNLwFjtdMwDGQcQyEGSPN1MtWBNDeRgauohibyZg+oRB23+kry8dDrGWLLIMmkVGGCQ10cVkHzLeOMcY9JPUFPsGPJDFcVyCKSOOPqqu5GIH3hQcYiM+TGPLzIstD3IwwlcVnHyJBRjbkGh3huTDdDtHUYxftAydWQaDJT70M8Y25g3ooYk5cQ45+qX1FuPCKFpcr9cCOyCkatyEbjH3O4sPNcjMJCEEIYmcZBjXVPB/Z2pmowO6xfFPBkITLlENc71unZjuo6BLvu94bvbDXhXBBDgfEI4KOQhCapSdtJzYwJc3RCNX2ZHG4aHyoiJpiq8Wpnhy1tGtZCkEQhG5JI/xPlrH365Mbk7cHO1j7eZqjXlNfc+b1Wf6TD3+2juVh5FjWxKS6SDjGTNEQi8T3LwK7zRX5w0owwUpCkJy/xAxSx/6/MXsi5W22mtclFt1SSSE7nbQdyNauQbgGMohlkI3j1Vb4PVucPbV2bhTv7j514q3e3zd6/cNbxarkxcC1BkbxiF9RJzRhKOOjLFljrXujf8AYd3N4rJzJG4m5JBkJJ/EXiNngl8azEuPAMbcRCRkIRdt03qO+f6uNzsHXTxgzPCff4JcxDmNzouMmoXMJmIcLyuUnpJgzs9ZvITqjV/6TVtKa/cJ3ltm2xjGozZjDqJ57hmdkGOsQoh5mWgzM6wyefSIm6/Vn6lGYfi4yEQ5wkCXyaZfzUwPk8vXlCy0vM8oN54yFiRWQnQOY1GYQnVHpqvXdDkk5f01HmrsQe2TMIlJs5iA/VKONVhBlSIy220lxkHR0kOYJAm4CRiIgbOwRHF5f7lFPOolsbXsB5iR9crXcGh4oyxkIQfVJ6iw5rbQGwkd0SDlJGSRaHGrYbHDNvhp2DmrkJ7P3qv79qy16urgr63tdpNvLnH7CUbNmzZsq/wCfsUjseeS9wHcgnM6bkkEUgtNK2ZoZKCZUoyE/EItHiNqNsdmIdOyiisfsq2bP1bdv/n/WsneqY8SOR0+3ZRRs4aafb+rZsk/q9iOzxpWNQTbXgzOmbSs5eXzPpZiIMYlydOKCOxjIVxGMg+qv5aDpqf2L2005xMz9X3v+aY4ZtwK3zrZtFRt4bhFs2+z9eyj+72/3LM0ynBQ8OQzq6OiUNhEa5chPTzErvFtrCwb1kGMkTeUZB6QpE2tlobv8J3EpqNpSbXH3qq9u3b//ACi96lqbsdj0IR7BCoH5aKdu3ZTs/wDJbte/1ZK5W3k2Dd1GMsrfUo0vqIc1nrCIhCDHIVuMgyDJlJ9imjYLCttqp2bNlRf117f8f/P+9LbnVt2Yfb7Nm3bs2Vj83s2/e/5/3oZnfmD9w/tFdAPiMuMhNISHuVnBcijoaNC84XLcEJpSJrfKNgGbUVHkGUY+OnZ+rZUgrxVtZXmigVVVFFLj27Nmzbt9mxLolTvzYu5WcYWpCaRJCDjSs3HF9yMfcWhx1t2iv59lO3bTsrH5vZt9ntSa65Nv28Pl/wCSW6HDp685/qHsMkxOMko0Y8MS5ZlcWUMY0CzNVRUWnZVt2U7f+5NzUbKsMe3bs9u1A/kKgvCMzeRQMcsmqTqKs1Gyfh9nl/uUZ0bNhP6kJIwJqAvxkHKIYu4uobsXgMsgySS9Nce2uK9jKnbxVe2snm2+3+ta3dQ5ILEHsprq2bFFyuHpzn+pmL/1He7pYZHjC4DGQg/iCEy+4uZ2F5RyDiickfMRkH3SZi3mFz1nM+qr28e2knt2bNv66dn/AJf1LB2cNGy3PvLsybgPaP0//l/u/wDJV3SPspzSPij174d/qafAmftx0Slbxjj9LLVZozMHBICFHJHJ3VZQKkDi2VUU001HbDrJt2bPv7Y/69qFFczjE/DSTbsEOThp9mz2Uro3ndOH9i54Z2Z03rgEOIZMwfbVggn5pxXyvw8hCE7qTXF+ZnZB7BEqo2ViJVV7Nv8AXt/vStpiy4jMTbS7Ls25n/f6i19OfYdPH9efDv8Am0vs5O1uObBGMo42/dVcDQDXjroKycCjGP1ZNQiFtF3cusN1EIWquul3Js27dmzbt2Vf3pnQWpw3YVV1baqqDybNu3b/AFVf3rfYRz7uH7er/DW1oa6kOOMbcRBjjr6UagQZoycAyykISftDTG2NBP2zOs1FJKz0yE27f36vbw+3b/8Ap/UgbrVtbjurejbVSEIx7KKNm39VKwjb+Ym2h5x0R2+GQTgpJRx9saX+7QXh04fEGIrcpI4z9IY1Zbbkem3i9hNv6v1bE5vdobAdv+AfDs2M9lOzZsq2+zZsq+9s9n/ihv6U9eHP9Cpmb3k/bz0RN2uW3GPSjQd4trHGzpwSMQoidPVL6iLqc127CjEgattJKh/rq2+bbt/+qYYXYBd2Rg4KPYQxAeyqur9e3am0m1lfnxZj9CWJrzBXKRu1bkzPUjWSNht9Z3TiiiiSIckg10Gzhpblqqo2eypxXITbt/Xtqq/v/WrMC07DYhvAq9nEOigg6adv69myn+5KWMsr14/o5XfwPguhkdDKNwUeXJqlVhra7Mw5ochG4suTpSLoG8e3h2298Tg2SAb+wdft28dP/n/Wud3t+ZtYSthlJQCh4PbTRs2+zZsS6cFvhZXrzn2DDX73aXgY5UWXINMMK3508dOB8ekNZcPxDgeyrbt27Nv9ezZt9mz/ANFtNzDQR70XYSikmyose3ZV+vy/3frWZ/u1zefZNtLbhv3aJuM4CFJGQhCD6v8AqND2GQzYddBxNiFcSEH6Y1fid+ZtY7tVQWumoVAhU7dm39dNOz+rYr2DUb+62SWimv2M/Z/V7P8A+FJpzcx68+XMDeJwtWZ643rd04kH3UHioxHdreDI15ZwVwPlyfL/ANERLk9TV2zoHt4adtcns9n7396XPnxXFhGSuvbUTa8Jt4tv3v8A6qPTn6pEu7/yruQRhf8AItDlK8dDGOTukXoDdLuxfYbszeBiRzcCjHzBO0NcR3SgodbyKtpKKa9oG8tG3bs/XTX/AIvb/evfW4liFzw7KxUbdlLMpdn6vZ7K9v8AXt/5rg/iPqNPwekfDfTuPz2ckN/+F29jW6+IEQmXHpDj1EneXI9ysLgdZBFcWvTP3YyZafMDVDwrcD+Wo20kXHXTsq28P936/wDuXP7tcT7QN9uwlVNWz9eyqny1f/XZ+tctOff+vq7W/P048+zj6Kbk8JcijrHcnInhf2gcireW19eBMxgIQcRCSEo6o0VhgdNdHMVU7KjDJ5a9uz27di0rYVLfBreuimmmtxqVbNn66/8AntWfT7P2IYje1hWtnu5cO31ZHJGDcZCD7o5F5X3hXL9NrNAxINiMWZHpiXvXA97c32+24D2uh0F0zJsLQUdNVJP+ezbsVF23ZYbqDegbbBZdoa2XHto5Ifs9v9+z9X6v/JXHTcv5fv6KzMwePH17+L5w4V3YvrxeRgy9SNPA4JfGtY6AZrgRMyP5i6xttoLbiu4AAKgYW5MunZs/VR/yVJ7K2YiJUGioe3++murZ/wD9XVS6jyU3Lo86/m4i8DWG8uBnaFGQo0GZn7yEPgJIQS7ZZ247gUc4xm/+ejZV/wDyrT4Zt9tttZwNADNX/XXsp/XtVvLqPL/wrr9A7ad/Hm4V7tIF0MBB5ZepHpKe5xhKQdYyiHqZa75hOxMrjTsqO1AWrb/31UbFc9w8xpKT2NG//wCzYtqdV4f4F/0Wn+x51NZwPCuKyDJlEy0P+jcLXgjJIWSMa9HtsPshA4qWwdm3+/hQzZg3cikrbt6q/wC/aKn/APpRadSn/gkS6NX/AGOAito2YiEjJzGmrC4Vm25FBSEKQci79csJ20jvZt2swZhPbV+r2e1f0xw4xbOiV0NQ01Uf1bdmz+pE+pT/AMCKdNr/ALHDwWwcVOR+WovQgLEyECimlq32U7Kdns2bKNn6lEfXT/wRv6bb/Y//2Q=="></p>	5	2020-10-23 17:14:29.01051	2020-10-23 17:14:29.01051	funny
114	Rips for Days boii	<p>Love me my bong rips</p><p><br></p><pre class="ql-syntax" spellcheck="false">var x  = () =&gt; {\nreutnr 'hi'\n}\n</pre><p><br></p><p><br></p><p><br></p>	13	2020-10-23 19:46:42.112931	2020-10-23 19:46:42.112931	code
115	dafew	<p>wegwe</p>	13	2020-10-23 19:46:50.557772	2020-10-23 19:46:50.557772	egg
116	ege	<p>egeeg</p>	13	2020-10-23 19:46:55.42033	2020-10-23 19:46:55.42033	ege
118	Demo	<p>THis is a demo note.</p>	5	2020-11-04 16:48:12.546171	2020-11-04 16:48:12.546171	demo
119	New Note	<p>Making myself some suuuper important notes.</p><p><br></p><p><br></p><p><br></p>	5	2020-11-16 17:17:02.206296	2020-11-16 17:17:02.206296	
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."schema_migrations" ("version") FROM stdin;
20201017213948
20201017213952
20201021222219
20201022180637
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: anansi
--

COPY "public"."users" ("id", "username", "created_at", "updated_at", "password_digest") FROM stdin;
5	Iggs	2020-10-22 18:39:09.372692	2020-10-22 18:39:09.372692	$2a$12$0quIrvCLvdB0THcJ1uJF6egEDIdTUvIOv955Ns9A/rdyaC/fL.sDK
6	hi	2020-10-23 15:23:11.591794	2020-10-23 15:23:11.591794	$2a$12$ate9yjF1AUG1Gd.r0Z2Kk.Cp6An.wOJ91Ti0frVuCrigVHXC5iehq
7	Igbert	2020-10-23 15:45:59.887914	2020-10-23 15:45:59.887914	$2a$12$afLk8JB5RnbBGrwd8PELpee/Mtv/T6WCOsoAT7JXTmZIUtDgqn7PK
8	Igb	2020-10-23 15:48:15.032105	2020-10-23 15:48:15.032105	$2a$12$XxZku8gZG55l3VZrrtKV5O4yWk6WNzGrMQm1bFd63Gs71jv40NugK
9	Wiggle	2020-10-23 15:53:48.805652	2020-10-23 15:53:48.805652	$2a$12$lNX6W5ENYfU95G2ObuZDLuQUjCLdAL6FiYpHIpUWrDXxDmPo.9Tdq
10	BongRipper	2020-10-23 15:56:38.23025	2020-10-23 15:56:38.23025	$2a$12$o3/DefHzfTuklh0IcMnYI.oPHkrbypwsBv9Vr.j69fXLSQUBDFqBW
11	BongRipper	2020-10-23 15:56:51.387797	2020-10-23 15:56:51.387797	$2a$12$CTsIDycMpxamBLcJRS931ufazXMx1uniKCAmRWCe7q/edYETl5tTi
12	BongRipper123	2020-10-23 16:00:16.077115	2020-10-23 16:00:16.077115	$2a$12$Rn7/ksXX6HeiK4dKrh5sYOM4eLkuahJv/ZaWYGLVmWTHvtcc2WGda
13	BongRipper420	2020-10-23 19:45:50.990663	2020-10-23 19:45:50.990663	$2a$12$TmZqUbiMKn7P3Zc14FF/w.93fQ6m6QUzjE1i/XkiVF2tmMq9yGwPy
\.


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anansi
--

SELECT pg_catalog.setval('"public"."notes_id_seq"', 119, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anansi
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 13, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."ar_internal_metadata"
    ADD CONSTRAINT "ar_internal_metadata_pkey" PRIMARY KEY ("key");


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."notes"
    ADD CONSTRAINT "notes_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: anansi
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- PostgreSQL database dump complete
--

--
-- Database "duelyNoted_test" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: duelyNoted_test; Type: DATABASE; Schema: -; Owner: anansi
--

CREATE DATABASE "duelyNoted_test" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "duelyNoted_test" OWNER TO "anansi";

\connect "duelyNoted_test"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "stereoBackend_developement" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: stereoBackend_developement; Type: DATABASE; Schema: -; Owner: anansi
--

CREATE DATABASE "stereoBackend_developement" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "stereoBackend_developement" OWNER TO "anansi";

\connect "stereoBackend_developement"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

